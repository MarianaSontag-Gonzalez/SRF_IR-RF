#The following code and associated data accompany the manuscript 
# "Wavelength calibration and spectral sensitivity correction of luminescence measurements for dosimetry applications tested on the IR-RF of K-feldspar" (2022) by
# Mariana Sontag-Gonzalez, Dirk Mittelstrass, Sebastian Kreutzer, Markus Fuchs
# Contact: Mariana.Sontag-Gonzalez@geogr.uni-giessen.de



# General ---------------------
{ library(Luminescence)
  library(data.table)
  library(dplyr)
  
  source('nm2rgb.R')
  
  #define colours
  t.steelblue <- rgb(70,130,180, #rgb.val[1], rgb.val[2], rgb.val[3],
                     max = 255,
                     alpha = (100 - 55) * 255 / 100)

  t.darkorange <- rgb(255,140,0, #rgb.val[1], rgb.val[2], rgb.val[3],
                      max = 255,
                      alpha = (100 - 55) * 255 / 100)
  
  t.black <- rgb(0,0,0, #rgb.val[1], rgb.val[2], rgb.val[3],
                      max = 255,
                      alpha = (100 - 65) * 255 / 100)
  
  #function to get local maxima              ##by https://stackoverflow.com/users/5614268/evan-friedland
  inflect <- function(x, threshold = 1){    
    up   <- sapply(1:threshold, function(n) c(x[-(seq(n))], rep(NA, n)))
    down <-  sapply(-1:-threshold, function(n) c(rep(NA,abs(n)), x[-seq(length(x), length(x) - abs(n) + 1)]))
    a    <- cbind(x,up,down)
    list(minima = which(apply(a, 1, min) == a[,1]), maxima = which(apply(a, 1, max) == a[,1]))
  }
  
  
  #function to obtain wavelength once wavelength-calibration parameters are set
  Pixel2Wavelength <- function(pixel=1:1024, WlCalPars=WlCalPars) {
    WlCalPars$x3*pixel^3 + WlCalPars$x2*pixel^2 + WlCalPars$x*pixel^1 + WlCalPars$n}
  
  #Gaussian functions
  OneGauss <-    function(par, Energy){par[3] * 1/(par[2]*sqrt(2*pi)) * exp(-0.5*((Energy-par[1])/par[2])^2)} #par[3] * exp(-(Energy-par[1])**2/(2 * par[2]**2)) }
  TwoGauss <-    function(par, Energy){par[3] * 1/(par[2]*sqrt(2*pi)) * exp(-0.5*((Energy-par[1])/par[2])^2) +
      par[6] * 1/(par[5]*sqrt(2*pi)) * exp(-0.5*((Energy-par[4])/par[5])^2)}
  ThreeGauss <-  function(par, Energy){par[3] * 1/(par[2]*sqrt(2*pi)) * exp(-0.5*((Energy-par[1])/par[2])^2) +
      par[6] * 1/(par[5]*sqrt(2*pi)) * exp(-0.5*((Energy-par[4])/par[5])^2) +
      par[9] * 1/(par[8]*sqrt(2*pi)) * exp(-0.5*((Energy-par[7])/par[8])^2)}
  
  
  
}



# Wavelength calibration -------------------------------------------------------


LampPeaks_ExpectedLocations <- data.frame("Element"=c("Hg", 
                                                      "Hg", 
                                                      "Y", "Hg", "Eu", "Eu",
                                                      "Eu", "Eu", "Eu", "Eu"),
                                          "Wavelength"=c(404.7, #could also be Tb at 403.3 nm
                                                         435.8, #could also be Tb at 432.6 nm
                                                         488.4, 546.1, 583.1, 617.3, 
                                                         643.8, 664.5, 707.7, 758.4))
#define colours for plot
OrderCol <-  c("red", "goldenrod1", "springgreen3", "darkorange", "steelblue") 

{ pdf(paste0("output/", "Fig2_FluorescentLamp_SpecPeaks_ForWavelengthCalib_150-800gr_165+300-500gr_260.pdf"), 
      width = 14, height = 6*1.55)
  
  par(mar=c(5,7,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  
  #(a) 150/800 grating
  par(fig=c(0,0.6,0.45,1))
  
  Signal <- read.csv( "data/Wavelength calibration/White light/WhiteLight_150-800grating_165.csv", stringsAsFactors = FALSE)
  BG     <- read.csv( "data/Wavelength calibration/White light/BG_150-800grating_165.csv", stringsAsFactors = FALSE)
  
  plot(Signal$Signal-BG$Signal, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,80000),
       xlab="", #"Pixel"
       ylab="", log="y",
       las=2
  )
  axis(1, at=c(1,1:5*1024/4), label=FALSE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected \n signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  n=10 #look for maxima within pixel ranges of length n
  max <- lapply(1:n, function(x) inflect(Signal$Signal-BG$Signal, threshold = x)$maxima)
  
  ##plot all peaks
  #  points( x=(0:1024)[max[[n]]][1:10], y=(Signal$Signal-BG$Signal)[max[[n]]][1:10], pch = 16, col = t.red, cex = 1)
  
  #visually determine which peaks corresponds to known emissions (unknown peaks are labelled 'NA')
  
  
  peaks <- c( NA, NA,
              LampPeaks_ExpectedLocations$Wavelength[2], NA, 
              LampPeaks_ExpectedLocations$Wavelength[3],
              LampPeaks_ExpectedLocations$Wavelength[4],
              LampPeaks_ExpectedLocations$Wavelength[5],
              LampPeaks_ExpectedLocations$Wavelength[6], NA, NA,
              LampPeaks_ExpectedLocations$Wavelength[9],
              LampPeaks_ExpectedLocations$Wavelength[10], NA, 
              2*LampPeaks_ExpectedLocations$Wavelength[1],
              2*LampPeaks_ExpectedLocations$Wavelength[2], NA,
              2*LampPeaks_ExpectedLocations$Wavelength[3], NA,
              2*LampPeaks_ExpectedLocations$Wavelength[4],
              2*LampPeaks_ExpectedLocations$Wavelength[5],
              2*LampPeaks_ExpectedLocations$Wavelength[6], NA,
              3*LampPeaks_ExpectedLocations$Wavelength[2], NA, rep(NA, 6)          
  )
  
  peaks_order <- c(NA, NA, 1, NA, 1, 1, 1, 1, NA, NA, 1, 1, NA,
                   2, 2, NA, 2, NA, 2, 2 ,2, NA, 3, NA, rep(NA,6))
  
  
  #check that you are considering all peaks
  length(peaks) == length(max[[n]])
  
  points( x=(1:1024)[max[[n]]], 
          y=(Signal$Signal-BG$Signal)[max[[n]]], pch = 14+peaks_order, col = OrderCol[peaks_order], cex = 1)
  
  lines(Signal$Signal-BG$Signal)
  
  text(x=(1:1024)[max[[n]]][!is.na(peaks)],
       y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)]*2,
       labels= round(peaks[!is.na(peaks)]), cex=0.8 )
  
  temp_data <- data.frame("x"=(0:1023)[max[[n]]][!is.na(peaks)] ,
                          "y"=peaks[!is.na(peaks)])
  
  text(x=0,y=55000,"(a)", cex=1.3)
  
  #(b) 
  par(new=TRUE)
  par(fig=c(0.6,1,0.45,1))
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="", #"Pixel"
       ylab="", col=NA)
  axis(1, at=c(1,1:5*1024/4), labels = FALSE)
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  points(temp_data, pch = 14+na.omit(peaks_order), col = OrderCol[na.omit(peaks_order)])
  
  legend("bottomright", pch=14+unique(na.omit(peaks_order)), col=OrderCol, 
         legend=c("First order", "Second order", "Third order")[unique(na.omit(peaks_order))], title="Signal maxima")
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800 <- WlCalPars_lm
  
  lines(0:1024, Pixel2Wavelength(0:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1390,"(b)", cex=1.3)
  
  
  #(c) 300/500 grating
  par(new=TRUE)
  par(fig=c(0,0.6,0,0.55))
  
  Signal <- read.csv( "data/Wavelength calibration/White light/WhiteLight_300-500grating_260.csv", stringsAsFactors = FALSE)
  BG     <- read.csv( "data/Wavelength calibration/White light/BG_300-500grating_260.csv", stringsAsFactors = FALSE)
  
  plot(Signal$Signal-BG$Signal, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,80000), 
       xlab="Pixel", 
       ylab="", log="y", las=2
  )
  axis(1, at=c(1,1:5*1024/4), label=TRUE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected \n signal (cts/0.05 s)    ", cex=1.5, side=2, line=4.5)
  
  n=10
  max <- lapply(1:n, function(x) inflect(Signal$Signal-BG$Signal, threshold = x)$maxima)
  
  ##plot all peaks
  #  points( x=(0:1024)[max[[n]]][1:10], y=(Signal$Signal-BG$Signal)[max[[n]]][1:10], pch = 16, col = t.red, cex = 1)
  
  #visually determine which peaks corresponds to known emissions (unknown peaks are labelled 'NA')
  peaks <- c(LampPeaks_ExpectedLocations$Wavelength[5],
             LampPeaks_ExpectedLocations$Wavelength[6],
             LampPeaks_ExpectedLocations$Wavelength[7],
             LampPeaks_ExpectedLocations$Wavelength[8], NA,
             LampPeaks_ExpectedLocations$Wavelength[9], NA, NA, 
             LampPeaks_ExpectedLocations$Wavelength[10], NA, NA, NA, 
             2*LampPeaks_ExpectedLocations$Wavelength[1], NA, NA, NA, NA, NA, NA, 
             2*LampPeaks_ExpectedLocations$Wavelength[2], rep(NA, 6), 
             2*LampPeaks_ExpectedLocations$Wavelength[3], rep(NA, 7))
  
  peaks_order <- c(1, 1, 1, 1, NA, 1, NA, NA, 1, NA, NA, NA, 2, rep(NA,6), 2, rep(NA, 6), 2, rep(NA, 7))
  #check that you are considering all peaks
  length(peaks) == length(max[[n]])
  
  points( x=(1:1024)[max[[n]]], 
          y=(Signal$Signal-BG$Signal)[max[[n]]], pch = 14+peaks_order, col = OrderCol[peaks_order], cex = 1)
  
  lines(Signal$Signal-BG$Signal)
  
  text(x=(1:1024)[max[[n]]][!is.na(peaks)],
       y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)]*2,
       labels= round(peaks[!is.na(peaks)]), cex=0.8 )
  legend("topright", pch=16, col=2, legend="Signal maxima (nm)")
  
  temp_data <- data.frame("x"=(0:1023)[max[[n]]][!is.na(peaks)] ,
                          "y"=peaks[!is.na(peaks)])
  
  text(x=0,y=55000,"(c)", cex=1.3)
  
  
  #(d) 
  par(new=TRUE)
  par(fig=c(0.6,1,0,0.55))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(550,1100),
       xlab="Pixel", ylab="", col=NA)
  axis(1, at=c(1,1:5*1024/4))
  axis(2, at=seq(500,1500,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  points(temp_data, pch = 14+na.omit(peaks_order), col = OrderCol[na.omit(peaks_order)])
  
  legend("bottomright", pch=14+unique(na.omit(peaks_order)), col=OrderCol, 
         legend=c("First order", "Second order", "Third order")[unique(na.omit(peaks_order))], title="Signal maxima")
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n), digits=3))~"     "), cex=1.1)
  
  #save parameters to use later
  WlCalPars_lm_300_500 <- WlCalPars_lm
  
  lines(0:1024, Pixel2Wavelength(0:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1095,"(d)", cex=1.3)
  
  dev.off()
}





#  Alternative wavelength calibrations -----------------------------------------


## by Hg(Ar) lamp --------------------------------------------------------------
{ pdf(paste0("output/", "FigA1_Hg-Ar_SpecPeaks_ForWavelengthCalib_150-800gr_165.pdf"), width = 14, height = 6)
  
  par(mar=c(5,6,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  par(fig=c(0,0.6,0,1))
  
  Data <- read.csv( "data/Wavelength calibration/Hg-Ar lamp/Hg-0,001s-closedSlit.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  BG <- read.csv(   "data/Wavelength calibration/Hg-Ar lamp/BG_0,001s-165nm_closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  
  Signal <- Data$Intensity..counts.-BG$Intensity..counts.
  
  plot(
    Signal, type="l",
    xaxt="n", yaxs="i",
    # xlim=c(1,1024), 
    ylim=c(100,100000),
    xlab="Pixel",
    ylab="", log="y",
    las=2,
    col="darkred"
  )
  axis(1, at=c(1,1:5*1024/4), label=TRUE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  #get peaks
  n=10
  max <- lapply(1:n, function(x) inflect(Signal,
                                         threshold = x)$maxima)
  ##plot all identified peak positions
  #points( x=(1:1024)[max[[n]]], y=Signal[max[[n]]], pch = 1, col = 1, cex = 1)
  
  
  Pixel_peaks <- (1:1024)[max[[n]]]
  
  #define expected spectral lines based on lamp manufacturer specifications
  HgAr_lines <- c(253.7, 302.2, 312.6, 334.0, 365.0, 404.7, 435.8, 546.1, mean(c(577.0, 579.0)))
  
  #manually define which peaks correspond to which wavelengths
  Wavelengths_peaks <-c(1*HgAr_lines[7],
                        2*HgAr_lines[1],
                        1*HgAr_lines[8:9],
                        2*HgAr_lines[3:5],
                        3*HgAr_lines[1],
                        2*HgAr_lines[6:7],
                        3*HgAr_lines[2:3],
                        NA,
                        4*HgAr_lines[1],
                        NA,
                        mean(2*HgAr_lines[8],3*HgAr_lines[5]),
                        2*HgAr_lines[9],
                        NA,
                        mean(4*HgAr_lines[2], 3*HgAr_lines[6]),
                        #4*HgAr_lines[3],
                        5*HgAr_lines[1],
                        3*HgAr_lines[7],
                        4*HgAr_lines[4],
                        NA
  )
  
  #check that you are considering all peaks
  length(Pixel_peaks) == length( Wavelengths_peaks)
  
  #define colours for plot
  OrderCol <-  c("red", "goldenrod1", "springgreen3", "darkorange", "steelblue") 
  
  points(x=(1:1024)[max[[n]]][!is.na(Wavelengths_peaks)], y=Signal[max[[n]]][!is.na(Wavelengths_peaks)],
         col = OrderCol[c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)][!is.na(Wavelengths_peaks)],
         pch = 14+c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)[!is.na(Wavelengths_peaks)], cex = 1)
  
  
  lines(Signal)
  
  temp_data <- data.frame("x"=Pixel_peaks ,
                          "y"=Wavelengths_peaks)
  
  text(x=0,y=80000,"(a)", cex=1.3)
  
  
  #B 
  par(new=TRUE)
  par(fig=c(0.6,1,0,1))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       las=2,
       xaxt="n",#xaxs="i", yaxs="i",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab="", 
       col=OrderCol[c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)],
       pch=14+c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800_Hg <- WlCalPars_lm
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1400,"(b)", cex=1.3)
  
  legend("bottomright",  col=OrderCol, 
         pch=14+1:5, legend=c("First", "Second", "Third", "Fourth", "Fifth"), title="Signal order")
  
  dev.off()
}


## by solar simulator peaks (Fig S2) -------------------------------------------
{ pdf(paste0("output/", "FigA2_SLS_SpecPeaks_ForWavelengthCalib_150-800gr_165.pdf"), width = 14, height = 6)
  
  par(mar=c(5,6,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  par(fig=c(0,0.6,0,1))
  
  Data_IR    <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_IR_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_red   <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_red_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_amber <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_amber_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_green <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_green_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_blue  <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_blue_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_UV    <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_UV_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  BG         <- read.csv( "data/Wavelength calibration/Solar simulator/BG_0,001s_165.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  
  Signal_IR    <- Data_IR$Intensity..counts.- BG$Intensity..counts.
  Signal_red   <- Data_red$Intensity..counts.- BG$Intensity..counts.
  Signal_amber <- Data_amber$Intensity..counts.- BG$Intensity..counts.
  Signal_green <- Data_green$Intensity..counts.- BG$Intensity..counts.
  Signal_blue  <- Data_blue$Intensity..counts.- BG$Intensity..counts.
  Signal_UV    <- Data_UV$Intensity..counts.- BG$Intensity..counts.
  
  plot(Signal_IR, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,10000),
       xlab="Pixel",
       ylab="", log="y",
       las=2,
       col="darkred"
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  lines(Signal_IR, col="darkred")
  lines(Signal_red, col="red")
  lines(Signal_amber, col="goldenrod2")
  lines(Signal_green, col="springgreen2")
  lines(Signal_blue, col="blue")
  lines(Signal_UV, col="lightblue")
  
  mtext("Background-corrected signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  legend("topright", lty=1, col=c("darkred", "red", "goldenrod2", "springgreen2", "blue", "lightblue"), title="LED",
         legend=c("IR", "red", "amber", "green", "blue", "UV"))
  
  #get peak positions
  n=10
  max_IR <- lapply(1:n, function(x) inflect(Signal_IR[Signal_IR>30],
                                            threshold = x)$maxima)
  max_red <- lapply(1:n, function(x) inflect(Signal_red[Signal_red>30],
                                             threshold = x)$maxima)
  max_amber <- lapply(1:n, function(x) inflect(Signal_amber[Signal_amber>30],
                                               threshold = x)$maxima)
  max_green <- lapply(1:n, function(x) inflect(Signal_green[Signal_green>30],
                                               threshold = x)$maxima)
  max_blue <- lapply(1:n, function(x) inflect(Signal_blue[Signal_blue>30],
                                              threshold = x)$maxima)
  max_UV <- lapply(1:n, function(x) inflect(Signal_UV[Signal_UV>30],
                                            threshold = x)$maxima)
  
  #correct for repeated signal maxima in green peak
  max_green[[n]] <- max_green[[n]][!duplicated(Signal_green[Signal_green>30][max_green[[n]]])]
  
  points( x=(1:1024)[Signal_IR>30][max_IR[[n]]], y=Signal_IR[Signal_IR>30][max_IR[[n]]], pch = 14+1, col = "darkred", cex = 1)
  
  points( x=(1:1024)[Signal_red>30][max_red[[n]]], y=Signal_red[Signal_red>30][max_red[[n]]], pch = 14+1:2, col = "red", cex = 1)
  
  points( x=(1:1024)[Signal_amber>30][max_amber[[n]]], y=Signal_amber[Signal_amber>30][max_amber[[n]]], pch = 14+1:2, col = "goldenrod2", cex = 1)
  
  points( x=(1:1024)[Signal_green>30][max_green[[n]]], y=Signal_green[Signal_green>30][max_green[[n]]], pch = 14+1:2, col = "springgreen2", cex = 1)
  
  points( x=(1:1024)[Signal_blue>30][max_blue[[n]]], y=Signal_blue[Signal_blue>30][max_blue[[n]]], pch = 14+1:2, col = "blue", cex = 1)
  
  points( x=(1:1024)[Signal_UV>30][max_UV[[n]]], y=Signal_UV[Signal_UV>30][max_UV[[n]]], pch = 14+2, col = "lightblue", cex = 1)
  
  
  Pixel_peaks <- c((1:1024)[Signal_IR>30][max_IR[[n]]],       #IR
                   (1:1024)[Signal_red>30][max_red[[n]]],     #red
                   (1:1024)[Signal_amber>30][max_amber[[n]]], #amber
                   (1:1024)[Signal_green>30][max_green[[n]]], #green
                   (1:1024)[Signal_blue>30][max_blue[[n]]],   #blue
                   (1:1024)[Signal_UV>30][max_UV[[n]]]       #UV
                   
  )
  
  #manually assign peak to LED wavelength
  Wavelengths_LEDs <- c(850,        #IR
                        625, 2*625, #red
                        590, 2*590, #amber
                        523, 2*523, #green
                        462, 2*462, #blue
                        2*365       #UV
  )
  
  #check all peaks were considered
  length(Pixel_peaks) == length( Wavelengths_LEDs)
  
  temp_data <- data.frame("x"=Pixel_peaks ,
                          "y"=Wavelengths_LEDs)
  
  text(x=0,y=7800,"(a)", cex=1.3)
  
  
  #B 
  par(new=TRUE)
  par(fig=c(0.6,1,0,1))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       las=2,
       xaxt="n",#xaxs="i", yaxs="i",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab="", 
       col=c("darkred", rep("red",2), rep("goldenrod2",2), rep("springgreen2", 2),
             rep("blue", 2), rep("lightblue", 1)),
       pch=14+c(1, 1:2, 1:2, 1:2, 1:2, 2))
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  legend("bottomright",  col="darkgrey", 
         pch=14+1:5, legend=c("First", "Second", "Third", "Fourth", "Fifth")[1:2], title="Signal order")
  
  PosNeg <- WlCalPars_lm>0
  
  
  mtext(bquote("f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800_sls <- WlCalPars_lm
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1400,"(b)", cex=1.3)
  
  dev.off()
}


## Plot Fig 3: comparison of wavelength calibration methods -------------------
{pdf(paste0("output/", "Fig3_WavelengthCalibrationComparison.pdf"), width = 7, height = 6)
  
  par(mar=c(5,6,1,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  plot(NA,NA,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab=""
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800), col=1)
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg), col=2)
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls), col=4)
  
  
  legend("topleft",  col=c(1,2,4), 
         lty=1, legend=c("Fluorescent lamp", 
                         "Hg(Ar) lamp", 
                         "'SLS' LEDs"), title="Calibration method")
  
  #inset showing calibrations in relation to Hg)AR) lamp calibration
  par(new=TRUE)
  par(fig=c(0.48,1,0.11,0.57), mgp=c(1.6,0.5,0))
  
  plot(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
       Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)/
         Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
       type="l", col=2,
       ylim=c(0.94,1.08), yaxs="i",
       xaxt="n", yaxt="n",
       xlab="Wavelength (nm)", ylab="Wavelength relative to      \n Hg(Ar) calibration (a.u.)     ", 
       cex.lab=1)
  axis(1, at=seq(400,1400,400), cex.axis=1)
  axis(1, at=seq(400,1400,100), labels = FALSE, tck=-0.02)
  axis(2, at=seq(0.94,1.08,0.06), cex.axis=1)
  axis(2, at=seq(0.94,1.08,0.02), labels = FALSE, tck=-0.02)
  
  lines(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800)/
          Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        col=1)
  lines(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)/
          Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        col=4)
  
  dev.off()  
  
}

Differences <- data.frame("WhiteLight_Hg" = abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)),
                          "WhiteLight_sls"= abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)),
                          "Hg_sls"        = abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)  - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)))

print(paste0("Maximum difference between fluorescent white light and Hg(Ar) lamp calibrations in the range 500-1000 nm is: ",
             round(max(Differences$WhiteLight_Hg[Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) %between% c(500,1000) &
                                                   Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg) %between% c(500,1000)]
             )), " nm."))


# Efficiency calibration  ------------------------------------------------------


## Datasheet SRF ---------------------------------------------------------------


## Load datasheet sensitivity
{#a) longpass filter 500 nm
LongPassFilter500_T  <- read.csv("data/Datasheets/Filter LP 500 nm.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #https://www.thorlabs.com/newgrouppage9.cfm?objectgroup_id=6082

#b) fused silica lens (1x magnification) at entry of fibre optic bundle
AttachmentOptics     <- read.csv("data/Datasheets/RF1xOSL2x_lens.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") # #48-836 https://www.edmundoptics.com.au/f/uv-fused-silica-double-convex-dcx-lenses/12412/

#c) quartz fibre optic bundle
Fibre_T              <- read.csv("data/Datasheets/Fibre Optic Quartz T.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #https://qd-europe.com/pl/en/product/fiber-optic-light-sources/
Fibre_T$Transmittance <- (sqrt(Fibre_T$Transmittance))^3#datasheet is given for 2 m, correct for true length of 3 m

#d) coating of spectrometer optics
SpecCoating_R        <- read.csv("data/Datasheets/SR163 coatings.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #Sheet from LexFlash

#e) diffraction grating 
Grating300_500_QE_polarised    <- read.csv("data/Datasheets/Grating 300-500.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM")  # Uncertainty: 3%; https://www.gratinglab.com/Products/Product_Tables/Efficiency/Efficiency.aspx?catalog=53-*-270R
Grating300_500_QE <- data.frame("Wavelength"=Grating300_500_QE_polarised$Wavelength,
                                "QE"=rowMeans(Grating300_500_QE_polarised[,c("p_plane", "s_plane")], na.rm = FALSE, dims = 1)
)#get mean of s- and p-planes since our light is not polarized

#extrapolate towards higher wavelengths
lm_grating_extrapolate_high <- lm(Grating300_500_QE$QE[Grating300_500_QE$Wavelength >750]~Grating300_500_QE$Wavelength[Grating300_500_QE$Wavelength >750])
#extrapolate towards lower wavelengths
lm_grating_extrapolate_low <- lm(Grating300_500_QE$QE[Grating300_500_QE$Wavelength <350]~Grating300_500_QE$Wavelength[Grating300_500_QE$Wavelength <350])
#join
Grating300_500_QE_extrapolated <- data.frame("Wavelength"=c(Grating300_500_QE$Wavelength, seq(801,1200), seq(200,300)),
                                             "QE"=c(Grating300_500_QE$QE, 
                                                    seq(801,1200)*coefficients(lm_grating_extrapolate_high)[2] + coefficients(lm_grating_extrapolate_high)[1], 
                                                    seq(200,300)*coefficients(lm_grating_extrapolate_low)[2] + coefficients(lm_grating_extrapolate_low)[1])
)



Grating150_800_QE    <- read.csv("data/Datasheets/Grating 150-800.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM")  # Uncertainty: 3%; https://www.gratinglab.com/Products/Product_Tables/Efficiency/Efficiency.aspx?catalog=53-*-426R
Grating150_800_QE$QE <- rowMeans(Grating150_800_QE[,c("p_plane", "s_plane")], na.rm = FALSE, dims = 1)  #get mean of s- and p-planes since our light is not polarized

#f) CCD camera
CCDCameraQE          <- read.csv("data/Datasheets/DU920P BU -100degC QE.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #Sheet from LexFlash
}

#calculate SRFs
PlotX <- 200:1400
SRF_datasheet_150_800 <- data.frame("Wavelength"=PlotX,
                                    "Factor"=approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
                                      approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
                                      approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
                                      approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y)

SRF_datasheet_300_500 <- data.frame("Wavelength"=PlotX,
                                    "Factor"=approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
                                      approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
                                      approx(x=Grating300_500_QE_extrapolated$Wavelength, y=Grating300_500_QE_extrapolated$QE, xout=PlotX, rule=2:2)$y*
                                      approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y)

{pdf(paste0("output/", "Fig4_SRF_Datasheet_wIndiv_500LP_150-800(a)+_300-500(b).pdf"), width = 7*2, height = 6)
  
  
  par(mfcol=c(1,2), mar=c(5,5,1,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  PlotLim <- c(300,1300)
  PlotX <- 200:1400
  
  #
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1.1),
       xlab="Wavelength (nm)",
       ylab="Relative efficiency")
  
  lines(LongPassFilter500_T, col="darkgrey")
  lines(AttachmentOptics$Wavelength, AttachmentOptics$Transmission, col="darkgrey")
  lines(x=max(AttachmentOptics$Wavelength):max(PlotX), y= rep(AttachmentOptics$Transmission[length(AttachmentOptics$Transmission)], length(max(AttachmentOptics$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  lines(Fibre_T, col="darkgrey")
  lines(SpecCoating_R, col="darkgrey")
  lines(Grating150_800_QE$Wavelength, Grating150_800_QE$QE, col="darkgrey")
  lines(x=200:min(Grating150_800_QE$Wavelength), y=  rep(Grating150_800_QE$QE[1], length(200:min(Grating150_800_QE$Wavelength))), lty=2, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  lines(x=max(CCDCameraQE$Wavelength):max(PlotX), y= rep(CCDCameraQE$QE[length(CCDCameraQE$QE)], length(max(CCDCameraQE$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  text(x=1307, y=0.92, labels="A")
  text(x=300, y=1.03, labels="B")
  text(x=1307, y=0.22, labels="C")
  text(x=300, y=0.88, labels="D")
  text(x=1307, y=0.43, labels="E")
  text(x=1307, y=0.05, labels="F")
  
  #plot SRF
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y
        ,
        col=1, lwd=2, lty=2
  )
  
  #plot SRF in wavelength range of interpolation
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y,
        col=1, lwd=2, lty=1
  )
  
  legend("topright", legend=sapply(c(bquote("Optical component"), bquote("S"["total datasheet"])),as.expression)
         , col=c("darkgrey", "black"), lty=1, lwd=c(1,2), bty="n")
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=305,y=1,"(a)", cex=1.3)
  
  
  
  
  #(b)
  PlotLim <- c(300,1000)
  PlotX <- 200:1400
  
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1.1),
       xlab="Wavelength (nm)",
       ylab="Relative efficiency")
  
  lines(LongPassFilter500_T, col="darkgrey")
  lines(AttachmentOptics$Wavelength, AttachmentOptics$Transmission, col="darkgrey")
  lines(x=max(AttachmentOptics$Wavelength):max(PlotX), y= rep(AttachmentOptics$Transmission[length(AttachmentOptics$Transmission)], length(max(AttachmentOptics$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  lines(Fibre_T, col="darkgrey")
  lines(SpecCoating_R, col="darkgrey")
  lines(Grating300_500_QE$Wavelength, Grating300_500_QE$QE, col="darkgrey")
  lines(x=Grating300_500_QE_extrapolated$Wavelength, Grating300_500_QE_extrapolated$QE, lty=2, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  
  text(x=1000, y=0.95, labels="A")
  text(x=300, y=1.03, labels="B")
  text(x=1000, y=0.48, labels="C")
  text(x=300, y=0.88, labels="D")
  text(x=1000, y=0.15, labels="E")
  text(x=1000, y=0.05, labels="F")
  
  #plot SRF (extrapolating nearest point)
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating300_500_QE_extrapolated$Wavelength, y=Grating300_500_QE_extrapolated$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y
        ,
        col=1, lwd=2, lty=2
  )
  
  #plot SRF in wavelength range of interpolation
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y,
        col=1,
        lwd=2, lty=1
  )
  
  
  legend("topright", legend=sapply(c(bquote("Optical component"), bquote("S"["total datasheet"])),as.expression),
         col=c("darkgrey", "black"), lty=1, lwd=c(1,2), bty="n")
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=305,y=1,"(b)", cex=1.3)
  
  dev.off()
}



## Calibration lamp measurement for SRF ----------------------------------------

#Load lamp calibration
CL6_Irr <- read.csv("data/Datasheets/CL6 Irradiance fromCD.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #From Bentham calibration CD

#Calculate relative photon emission
CL6_Irr$Energy <- 1239.84193 / CL6_Irr$Wavelength  # Energy = Planck constant * light speed / wavelength  = 4.13566769692e-15 eV*s * 299792458e+9 nm/s / wavelength in nm
CL6_Irr$Intensity <- CL6_Irr$Irradiance..mW.m.2.nm.1. # in mW * m^2 * nm^-1, which is equivalent to 10^-3 * 6.24 * 10^18 eV * s^-1 * m^2 * nm^-1
CL6_Irr$Rel_Photon_Emission <- 6.24e+15 * CL6_Irr$Intensity/CL6_Irr$Energy  #units: (eV * s^-1 * m^-2 * nm^-1) / eV, equivalent to s^-1 * m^-2 * nm^-1

#Load lamp measurement
#150-800 grating
temp_1 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_1_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
temp_2 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_2_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
temp_3 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_3_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
BG_1   <- read.csv("data/Lamp measurements/150-800 grating/BG_0,001s_165nm.csv", skip=9, header=TRUE, sep=";")
CL6_150_800_500LP <- data.frame("Wavelength"= Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800), 
                                "Intensity" = rowMeans(data.frame(temp_1$Intensity..counts.,
                                                                  temp_2$Intensity..counts.,
                                                                  temp_3$Intensity..counts.))-
                                  BG_1$Intensity..counts.
)

#300-500 grating
temp_1 <- read.csv("data/Lamp measurements/300-500 grating/CL6-1_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
temp_2 <- read.csv("data/Lamp measurements/300-500 grating/CL6-2_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
temp_3 <- read.csv("data/Lamp measurements/300-500 grating/CL6-3_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
BG_1   <- read.csv("data/Lamp measurements/300-500 grating/BG_RF1x_0,01s_1.csv", skip=9, header=TRUE, sep=";")
CL6_300_500_500LP <- data.frame("Wavelength"= Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500), 
                                "Intensity" = rowMeans(data.frame(temp_1$Intensity..counts.,
                                                                  temp_2$Intensity..counts.,
                                                                  temp_3$Intensity..counts.))-
                                  BG_1$Intensity..counts.
)

{ pdf(paste0("output/", "Fig5_SRF_CalibLamp_FullLength2.pdf"), width = 6*2, height = 6, bg="white")
  
  par( mar=c(5,5,1,2), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #150-800
  PlotLim=c(c(300,1450))
  PlotX <- 300:1500
  
  par( fig=c(0,0.5,0.4,1))
  plot(PlotX,     
       approx(x=CL6_Irr$Wavelength,
              y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y/
         max(approx(x=CL6_Irr$Wavelength,
                    y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y),
       type="l", lty=2, 
       xaxs="i",
       bty="n", xaxt="n",  yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       xlab="", ylab="Signal (a.u.)")
  
  axis(side=1, at=seq(200,1600,200), labels=FALSE)
  axis(side=2, at=c(0,0.5,1))
  
  legend("bottomright", legend=c("Emitted", "Measured"), lty=c(2,1), cex=1.2)
  
  
  par(new=TRUE, fig=c(0,0.5,0,0.55))
  plot(CL6_150_800_500LP$Wavelength, 
       CL6_150_800_500LP$Intensity/
         max(CL6_150_800_500LP$Intensity),
       type="l", lty=1, 
       xaxs="i",
       bty="n",  xaxt="n", yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       col="darkgrey",
       xlab="Wavelength (nm)", ylab="Signal (a.u.)")
  
  lines(CL6_150_800_500LP$Wavelength[CL6_150_800_500LP$Wavelength < 960],
        CL6_150_800_500LP$Intensity[CL6_150_800_500LP$Wavelength < 960]/
          max(CL6_150_800_500LP$Intensity),
        col=1)
  
  
  axis(side=1, at=seq(200,1600,200), labels=TRUE)
  axis(side=2, at=c(0,0.5,1))
  
  par(new=TRUE, fig=c(0,0.5,0,1))
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n", 
       ylab="", yaxt="n")
  
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  
  text(x=PlotLim[1]*1.16,y=1,"(a)", cex=1.3)
  
  #300/500
  PlotLim=c(c(500,1200))
  
  par(new=TRUE, fig=c(0.5,1,0.4,1))
  plot(PlotX,          
       approx(x=CL6_Irr$Wavelength,
              y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y/max(
                approx(x=CL6_Irr$Wavelength,
                       y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y) ,
       type="l", lty=2, 
       xaxs="i",
       bty="n", xaxt="n",  yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       xlab="", ylab="Signal (a.u.)")
  
  axis(side=1, at=seq(200,1600,200), labels=FALSE)
  axis(side=2, at=c(0,0.5,1))
  
  legend("bottomright", legend=c("Emitted", "Measured"), lty=c(2,1), cex=1.2)
  
  
  par(new=TRUE, fig=c(0.5,1,0,0.55))
  plot(CL6_300_500_500LP$Wavelength, 
       CL6_300_500_500LP$Intensity/ 
         max(CL6_300_500_500LP$Intensity),
       type="l", lty=1, 
       xaxs="i",
       bty="n",  xaxt="n", yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       col="darkgrey",
       xlab="Wavelength (nm)", ylab="Signal (a.u.)")
  
  lines(CL6_300_500_500LP$Wavelength[CL6_300_500_500LP$Wavelength < 960],
        CL6_300_500_500LP$Intensity[CL6_300_500_500LP$Wavelength < 960]/
          max(CL6_300_500_500LP$Intensity),
        col=1)
  axis(side=1, at=seq(200,1600,200), labels=TRUE)
  axis(side=2, at=c(0,0.5,1))
  
  par(new=TRUE, fig=c(0.5,1,0,1))
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n", 
       ylab="", yaxt="n")
  
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  
  text(x=PlotLim[1]*1.06, y=1,"(b)", cex=1.3)
  dev.off()
}




## SRF lamp vs datasheet -------------------------------------------------------

{pdf(paste0("output/", "Fig6_SRF_CalibLamp_ClosedSlit_150-800_+_300-500_normDS.pdf"), width = 14, height = 6)
  
  par(mar=c(5,5,1,2), mgp=c(3,1,0), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #
  matching_wavelength <- 700
  PlotLim <- c(c(300,1400))
  PlotX <- 200:1400
  
  par(fig=c(0,0.5,0,1))
  plot(PlotX,
       approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
         approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
         approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
         approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y ,
       type="l", 
       xlim=PlotLim, ylim=c(0, 0.5),
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Normalised relative efficiency", # (a.u.)
       col="darkorange", lty=2, lwd=3
  )
  #use a full line where the SRF is reliable
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y ,
        col="darkorange", lty=1, lwd=3)
  
  #Define SRF (measured/emitted) only for reliable wavelengths (i.e., within first-order limits of 500LP filter (960 nm))
  SRF_lamp_150_800 <- data.frame("Wavelength"=round(CL6_150_800_500LP$Wavelength, 4),
                                 "Factor"=CL6_150_800_500LP$Intensity/approx(x=CL6_Irr$Wavelength,
                                                                             y=CL6_Irr$Intensity/CL6_Irr$Energy, xout=CL6_150_800_500LP$Wavelength)$y
  )[CL6_150_800_500LP$Wavelength < 960,]
  SRF_lamp_150_800$Factor <- SRF_lamp_150_800$Factor/max(SRF_lamp_150_800$Factor, na.rm=TRUE)  ## normalise to 1 to later use with apply_EfficiencyCorrection()
  
  lines(SRF_lamp_150_800$Wavelength,
        SRF_lamp_150_800$Factor/SRF_lamp_150_800$Factor[which.min(abs(SRF_lamp_150_800$Wavelength - matching_wavelength))] * #normalise to matching_wavelength
         ( approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
             approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
             approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
             approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
             approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
             approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y )[which.min(abs(PlotX - matching_wavelength))]
        , col="steelblue", lty=1, lwd=3)
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=PlotLim[1]+40,y=1,"(a)", cex=1.3)
  
  
  legend(x=1000, y=0.25, legend=  sapply(c(bquote("S"["total datasheet"]), bquote("S"["total CL6 lamp"])),as.expression),
         lty=c(1,1), lwd=c(2,2), col=c("darkorange","steelblue"))
  
  par(new=TRUE)
  par(fig=c(0.22,0.5,0.45,1), mar=c(5,7,1,2), mgp=c(2,1,0))
  PlotX <- SRF_lamp_150_800$Wavelength
  plot(PlotX,
       (approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y /
          #normalise to matching_wavelength
          ( approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
              approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
              approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
              approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
              approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=matching_wavelength, rule=2:2)$y*
              approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y ) ) - 
         (SRF_lamp_150_800$Factor/SRF_lamp_150_800$Factor[which.min(abs(SRF_lamp_150_800$Wavelength - matching_wavelength))]),
       type="l", 
       xaxt="n", yaxt="n",
       ylim=c(-0.25,0.45),
       xlab="Wavelength (nm)", ylab="Relative efficiency \n difference (a.u.)", cex.lab=1, cex.axis=1,
       col=1, lty=1, lwd=1.5
  )
  axis(side=1, at=seq(200,1200,200), cex.axis=1)
  axis(side=1, at=seq(200,1200,100), labels=FALSE, tck=-0.02)
  axis(side=2, at=seq(-0.2,0.4,0.2), cex.axis=1)
  abline(h=0, lty=2, col="darkgrey")
  
  #(b)
  PlotLim <- c(450,1000)
  PlotX <- 200:1200
  
  par(new=TRUE)
  par(fig=c(0.5,1,0,1), mar=c(5,5,1,2), mgp=c(3,1,0))
  plot(PlotX,
       approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
         approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
         approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
         approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y 
       ,
       type="l", 
       xlim=PlotLim, ylim=c(0,0.5),
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Normalised relative efficiency", # (a.u.)
       col="darkorange", lty=2, lwd=3
  )
  #use a full line where the SRF is reliable
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y 
        ,
        col="darkorange", lty=1, lwd=3
  )
  
  #Define SRF (measured/emitted) only for reliable wavelengths (i.e., within first-order limits of 500LP filter (960 nm))
  SRF_lamp_300_500 <- data.frame("Wavelength"=round(CL6_300_500_500LP$Wavelength, 4),
                                 "Factor"=CL6_300_500_500LP$Intensity/approx(x=CL6_Irr$Wavelength,
                                                                             y=CL6_Irr$Intensity/CL6_Irr$Energy, xout=CL6_300_500_500LP$Wavelength)$y
  )[CL6_300_500_500LP$Wavelength < 960,]
  SRF_lamp_300_500$Factor <- SRF_lamp_300_500$Factor/max(SRF_lamp_300_500$Factor, na.rm=TRUE)  ## normalise to 1 to later use with apply_EfficiencyCorrection()
  
  lines(SRF_lamp_300_500$Wavelength,
        SRF_lamp_300_500$Factor/SRF_lamp_300_500$Factor[which.min(abs(SRF_lamp_300_500$Wavelength - matching_wavelength))] * #normalise to matching_wavelength
          ( approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
              approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
              approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
              approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
              approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
              approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y )[which.min(abs(PlotX - matching_wavelength))]
        , col="steelblue", lty=1, lwd=3)
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  legend("bottom", legend=  sapply(c(bquote("S"["total datasheet"]), bquote("S"["total CL6 lamp"])),as.expression),
         lty=c(1,1), lwd=c(2,2), col=c("darkorange","steelblue"))
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=PlotLim[1]*1.05,y=1,"(b)", cex=1.3)
  
  
  par(new=TRUE)
  par(fig=c(0.72,1,0.45,1), mar=c(5,7,1,2), mgp=c(2,1,0))
  PlotX <- SRF_lamp_300_500$Wavelength
  plot(PlotX,
       (approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y/
          (      approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y) ) - 
         (SRF_lamp_300_500$Factor/SRF_lamp_300_500$Factor[which.min(abs(SRF_lamp_300_500$Wavelength - matching_wavelength))]),
       type="l", 
       xaxt="n", yaxt="n",
       ylim=c(-0.25,0.45),
       xlab="Wavelength (nm)", ylab="Relative efficiency \n difference (a.u.)", cex.lab=1, cex.axis=1,
       col=1, lty=1, lwd=1.5
  )
  axis(side=1, at=seq(200,1200,200), cex.axis=1)
  axis(side=1, at=seq(200,1200,100), labels=FALSE, tck=-0.02)
  axis(side=2, at=seq(-0.2,0.4,0.2), cex.axis=1)
  abline(h=0, lty=2, col="darkgrey")
  dev.off()
}




# Example SRF use in RF -------------------------------------------------------

#get data file locations
xsygNames <- dir(getwd(), pattern = c('xsyg'), recursive = TRUE, ignore.case = TRUE)
xsygNames_BG   <- xsygNames[ grepl(xsygNames,pattern="Empty")]
xsygNames_Data <- xsygNames[!grepl(xsygNames,pattern="Empty")]

#run analysis for all background files
for (b in 1:length(xsygNames_BG)) {
  
  print(c("b=",b," of ",length(xsygNames_BG)))
  
  
  #load data
  obj_xsyg <- read_XSYG2R(
    xsygNames_BG[b],
    recalculate.TL.curves = TRUE,
    fastForward = FALSE,
    import = TRUE,
    pattern = ".xsyg",
    verbose = TRUE,
    txtProgressBar = TRUE
  )
  
  
  
  #analyse
  
  temp_obj <- obj_xsyg[[1]][["Sequence.Object"]]@records[[1]]
  
  if(grepl(temp_obj@recordType, pattern = "(Spectrometer)" ) ){
    
    #Calibrate wavelength
    if(grepl(xsygNames_BG[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800)
      
    } else if(grepl(xsygNames_BG[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500)
      
    } else { print("Error in re-calibration of wavelength!")}
    
    
    #Define sample name 
    if(grepl(xsygNames_BG[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      s=paste0("Empty_150-800_", b)
      
    } else if(grepl(xsygNames_BG[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      s=paste0("Empty_300-500_", b)
      
    } else { print("No grating specified!")}
    
    #remove outliers 
    plot_RLum.Data.Spectrum(temp_obj, main="0")
    
    temp_obj_noCosmic <- temp_obj
    
    
    for (n in 1:6) {
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 1,   #first smooth along t axis,
                                                  method =  "smooth")

      
      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n)
      
      
    }
    {
      
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  method.Pych.smoothing = 10,
                                                  method.Pych.threshold_factor = 1,
                                                  method =  "Pych")
      
      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n+1)
      
      
    }
    
    
    #Get median background
    medianBG <- unlist(lapply(1:nrow(temp_obj_noCosmic@data), function (x) median(temp_obj_noCosmic@data[x,]) ))
    
    plot(rownames(temp_obj_noCosmic@data),
         medianBG,
         xlab="Wavelength (nm)",
         ylab="Median RF backgroud (cts/1.2 Gy)",  #source dose rate * channel length = 0.061 Gy/s * 19 s
         type="l") 
    
    
    #save background
    assign(s, medianBG)
    
    
  } else {print("Wrong record type.")} #end if correct record type
}#end for xsyg


#run analysis for all data files
for (b in 1:length(xsygNames_Data)) {
  
  print(c("b=",b," of ",length(xsygNames_Data)))
  
  #load BG
  BG <-  if(grepl(xsygNames_Data[b], pattern = "150-800")) {
    eval(as.symbol("Empty_150-800_1"))
  } else if(grepl(xsygNames_Data[b], pattern = "300-500")) {
    eval(as.symbol("Empty_300-500_2"))
  } else {print("No BG available")}
  
  
  #load data
  obj_xsyg <- read_XSYG2R(
    xsygNames_Data[b],
    recalculate.TL.curves = TRUE,
    fastForward = FALSE,
    import = TRUE,
    pattern = ".xsyg",
    verbose = TRUE,
    txtProgressBar = TRUE
  )
  
  
  #analyse
  temp_obj <- obj_xsyg[[1]][["Sequence.Object"]]@records[[1]]
  
  if(grepl(temp_obj@recordType, pattern = "(Spectrometer)" ) ){
    
    #Background removal 
    temp_obj@data <- temp_obj@data - rep(BG, ncol(temp_obj@data))
    
    
    #Calibrate wavelength
    if(grepl(xsygNames_Data[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800)
      
    } else if(grepl(xsygNames_Data[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500)
      
    } else { print("Error in re-calibration of wavelength!")}
    
    #s=paste0("Gi326_90-200um_", b)
    
    #remove outliers 
    plot_RLum.Data.Spectrum(temp_obj, main="0")
    
    temp_obj_noCosmic <- temp_obj
    
    
    for (n in 1:6) {
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 1,   #first smooth along t axis,
                                                  method =  "smooth")

      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n)
      
      
    }
    {

      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  method.Pych.smoothing = 10,
                                                  method.Pych.threshold_factor = 1,
                                                  method =  "Pych")
      
      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n+1)
      
      
    }
    
     #round wavelength to match SRF
    rownames(temp_obj_noCosmic@data) <- round(as.numeric(rownames(temp_obj_noCosmic@data)),4)
    
    #build example of raw data
    channel <- 9 #20
    temp_data <- data.frame("Wavelength"=rownames(temp_obj_noCosmic@data),
                            "Signal_raw"=temp_obj_noCosmic@data[,9])  ##ifelse(ncol(temp_obj_noCosmic@data)<channel,9,channel)
    
    if(grepl(xsygNames_Data[b], pattern = "LP500") | grepl(xsygNames_Data[b], pattern = "500LP")){
      
      #remove data outside first-order signal wavelength range
      temp_obj_noCosmic_ForCorr <- temp_obj_noCosmic
      temp_obj_noCosmic_ForCorr@data <- temp_obj_noCosmic_ForCorr@data[as.numeric(rownames(temp_obj_noCosmic_ForCorr@data)) %between% c(525,960),]
      
      
      
      #Efficiency correction S_datasheet
      if(grepl(xsygNames_Data[b], pattern="150-800") ){
        
        temp_obj_noCosmic_Datasheet <- apply_EfficiencyCorrection(temp_obj_noCosmic_ForCorr, SRF_datasheet_150_800)
        
      } else if(grepl(xsygNames_Data[b], pattern="300-500") ){
        
        temp_obj_noCosmic_Datasheet <- apply_EfficiencyCorrection(temp_obj_noCosmic_ForCorr, SRF_datasheet_300_500)
        
      } 
      
      #save S_datasheet-corrected spectrum

      temp_data <- left_join(temp_data,
                             data.frame("Wavelength"=rownames(temp_obj_noCosmic_Datasheet@data),
                                        "Signal_Corr_Datasheet_9"=temp_obj_noCosmic_Datasheet@data[,channel])
      )
  
      
      #Efficiency correction S_lamp
      if(grepl(xsygNames_Data[b], pattern="150-800") ){
        
        temp_obj_noCosmic_Lamp <- apply_EfficiencyCorrection(temp_obj_noCosmic_ForCorr, SRF_lamp_150_800)
        
      } else if(grepl(xsygNames_Data[b], pattern="300-500") ){
        
        temp_obj_noCosmic_Lamp <- apply_EfficiencyCorrection(temp_obj_noCosmic_ForCorr, SRF_lamp_300_500)
        
      }
      
      #save S_lamp-corrected spectrum

      temp_data <- left_join(temp_data,
                             data.frame("Wavelength"=rownames(temp_obj_noCosmic_Lamp@data),
                                        "Signal_Corr_Lamp_9"=temp_obj_noCosmic_Lamp@data[,channel])
      )

      
      #Get details on IR-RF peak position
      print(paste0("The IR-RF peak centre wavelength of the raw data is ", round(mean(as.numeric(rownames(temp_obj_noCosmic_ForCorr@data))[temp_obj_noCosmic_ForCorr@data[,channel]==max(temp_obj_noCosmic_ForCorr@data[,channel])])), " nm."))
      print(paste0("The IR-RF peak centre wavelength of the SRF_datasheet-corrected spectrum is ", round(mean(as.numeric(rownames(temp_obj_noCosmic_Datasheet@data))[temp_obj_noCosmic_Datasheet@data[,channel]==max(temp_obj_noCosmic_Datasheet@data[,channel])])), " nm."))
      print(paste0("The IR-RF peak centre wavelength of the SRF_lamp-corrected spectrum is ", round(mean(as.numeric(rownames(temp_obj_noCosmic_Lamp@data))[temp_obj_noCosmic_Lamp@data[,channel]==max(temp_obj_noCosmic_Lamp@data[,channel])])), " nm."))
      
    } #end if 500LP filter
    
    #save example of raw data
    assign(paste0("Data_", b), temp_data)
    assign(paste0("DataFull_raw_", b), temp_obj_noCosmic@data)
    assign(paste0("DataFull_Datasheet_", b), temp_obj_noCosmic_Datasheet@data)
    assign(paste0("DataFull_Lamp_", b), temp_obj_noCosmic_Lamp@data)
    
  } else {print("Wrong record type.")} #end if correct record type
}#end for xsyg


##Plot Fig. 7
{ pdf(paste0("output/", "Fig7_SRF_RF_Gi326+Gi361.pdf"), width = 7*2, height = 6*1.3)
  
  par(mar=c(5,5,2,1), cex=1.35, cex.lab=1.4, cex.axis=1.2)
  
  #(a) #150-800 grating
  par(fig=c(0,0.42,0,1))
  #Gi326
  #load data
  #temp_data <- eval(as.symbol(paste0("Data_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
  temp_data_raw <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
  temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
  temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
  channel=150
  
  #set plot limits
  PlotLim <- c(400,1400)
  PlotLimY <- c(-0.05, 1.05)
  
  #plot raw spectrum
  plot(rownames(temp_data_raw),
       temp_data_raw[,channel]/max(temp_data_raw[,channel], na.rm=TRUE),
       type="l", lwd=2,
       xlim=c(PlotLim[1], PlotLim[2]), 
       ylim=c(PlotLimY[1], PlotLimY[2]+PlotLimY[2]-PlotLimY[1]), 
       xaxs="i", #xaxt="n", 
       yaxs="i", yaxt="n",
       xlab="Wavelength (nm)", ylab="Background-corrected RF (a.u.)")  
  
  #axis(1, at=seq(1.3, PlotLim[2], 0.1), labels = seq(1.3, PlotLim[2], 0.1))
  axis(1, at=seq(PlotLim[1], PlotLim[2], 100), labels = FALSE, tck=-0.01)
  axis(2, at=seq(0,PlotLimY[2], 0.5), labels = seq(0,PlotLimY[2], 0.5))
  axis(2, at=seq(0,PlotLimY[2], 0.25), labels = FALSE, tck=-0.01)
  
  abline(h=PlotLimY[2])
  axis(2, at=seq(0,PlotLimY[2], 0.5)+PlotLimY[2]-PlotLimY[1], labels = seq(0,PlotLimY[2], 0.5))
  axis(2, at=seq(0,PlotLimY[2], 0.25)+PlotLimY[2]-PlotLimY[1], labels = FALSE, tck=-0.01)
  
  #plot SRF_lamp-corrected spectrum
  lines(rownames(temp_data_Lamp),
        temp_data_Lamp[,channel]/max(temp_data_Lamp[,channel], na.rm=TRUE),
        col="steelblue",
        type="l", lwd=2)  
  
  #plot SRF_datasheet-corrected spectrum
  lines(rownames(temp_data_Datasheet),
        temp_data_Datasheet[,channel]/max(temp_data_Datasheet[,channel], na.rm=TRUE),
        col="darkorange",
        type="l", lwd=2)

  text(x=PlotLim[2]*0.93, y=0.95, "Gi326", font=2)
  
  #plot peak maxima
  points(x=mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5)
  points(x=mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="steelblue")
  

  
  #Details (not plotted)
  print(paste0("Gi326 150/800 grating: ",
               round(100*min((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), " to ",
               round(100*max((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), "%"))
  print(paste0(c("Raw: ", "Datasheet: ", "Lamp: "), c(mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
          mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
          mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))]))
  ), " nm"))
  
  #Gi361
  #load data
  temp_data_raw <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800"))))
  temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800"))))
  temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800"))))
  channel=154
  
  #plot raw spectrum
  lines(rownames(temp_data_raw),
        temp_data_raw[,channel]/max(temp_data_raw[,channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col=1,
        type="l", lwd=2)  
  
  #plot SRF_lamp-corrected spectrum
  lines(rownames(temp_data_Lamp),
        temp_data_Lamp[,channel]/max(temp_data_Lamp[,channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col="steelblue",
        type="l", lwd=2)  
  
  #plot SRF_datasheet-corrected spectrum
  lines(rownames(temp_data_Datasheet),
        temp_data_Datasheet[,channel]/max(temp_data_Datasheet[,channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col="darkorange",
        type="l", lwd=2)

  text(x=PlotLim[2]*0.93, y=0.95+PlotLimY[2]-PlotLimY[1], "Gi361", font=2)
  
  
  #plot peak maxima
  points(x=mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5)
  points(x=mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5, col="steelblue")
  
  #Details (not plotted)
  print(paste0("Gi361 150/800 grating: ",
               round(100*min((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), " to ",
               round(100*max((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), "%"))
  print(paste0(c("Raw: ", "Datasheet: ", "Lamp: "), c(mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))]))
  ), " nm"))
  
  #add wavelength colour bar  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.035,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=0.5 )
  points(200:1500, y=rep(0.5,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=0.5 )
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i", 
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=450,y=1.01,"(a)", cex=1.3)
  
  
  title(main=bquote("150/800 grating"))
  
  #(b)
  {par(new=TRUE)
  par(fig=c(0.40-0.02,0.80,0,1))
  
  #300-500 grating
  PlotLim <- c(500,1100)

  #load data
  temp_data_raw <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau"))))
  temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau"))))
  temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau"))))
  channel=150
  
  #plot raw spectrum
  plot(rownames(temp_data_raw),
       temp_data_raw[,channel]/max(temp_data_raw[as.numeric(rownames(temp_data_raw)) %between% c(750,950),channel], na.rm=TRUE),
       type="l", lwd=2,
       xlim=c(PlotLim[1], PlotLim[2]), 
       ylim=c(PlotLimY[1], PlotLimY[2]+PlotLimY[2]-PlotLimY[1]), 
       xaxs="i", xaxt="n", 
       yaxs="i", yaxt="n",
       xlab="Wavelength (nm)", ylab="")  
  
  axis(1, at=seq(PlotLim[1], PlotLim[2], 200), labels = TRUE)
  axis(1, at=seq(PlotLim[1], PlotLim[2], 100), labels = FALSE, tck=-0.01)
  axis(2, at=seq(0,PlotLimY[2], 0.5), labels = seq(0,PlotLimY[2], 0.5))
  axis(2, at=seq(0,PlotLimY[2], 0.25), labels = FALSE, tck=-0.01)
  
  abline(h=PlotLimY[2])
  axis(2, at=seq(0,PlotLimY[2], 0.5)+PlotLimY[2]-PlotLimY[1], labels = seq(0,PlotLimY[2], 0.5))
  axis(2, at=seq(0,PlotLimY[2], 0.25)+PlotLimY[2]-PlotLimY[1], labels = FALSE, tck=-0.01)
  
  #plot SRF_lamp-corrected spectrum
  lines(rownames(temp_data_Lamp),
        temp_data_Lamp[,channel]/max(temp_data_Lamp[as.numeric(rownames(temp_data_Lamp)) %between% c(750,950),channel], na.rm=TRUE),
        col="steelblue",
        type="l", lwd=2)  
  
  #plot SRF_datasheet-corrected spectrum
  lines(rownames(temp_data_Datasheet),
        temp_data_Datasheet[,channel]/max(temp_data_Datasheet[as.numeric(rownames(temp_data_Datasheet)) %between% c(750,950),channel], na.rm=TRUE),
        col="darkorange",
        type="l", lwd=2)
  
  text(x=PlotLim[2]*0.95, y=0.95, "Gi326", font=2)
  
  #plot peak maxima
  points(x=mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[as.numeric(rownames(temp_data_raw)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5)
  points(x=mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[as.numeric(rownames(temp_data_Datasheet)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[as.numeric(rownames(temp_data_Lamp)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="steelblue")

  
  
  #Details (not plotted)
  print(paste0("Gi326 300/500 grating: ",
               round(100*min((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), " to ",
               round(100*max((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), "%"))
  print(paste0(c("Raw: ", "Datasheet: ", "Lamp: "), c(mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))]))
  ), " nm"))
  
  
  #Gi361
  #load data
  temp_data_raw <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "GiveC"))))
  temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "GiveC"))))
  temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "GiveC"))))
  channel=154
  
  #plot raw spectrum
  lines(rownames(temp_data_raw),
        temp_data_raw[,channel]/max(temp_data_raw[as.numeric(rownames(temp_data_raw)) %between% c(750,950),channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col=1,
        type="l", lwd=2)  
  
  #plot SRF_lamp-corrected spectrum
  lines(rownames(temp_data_Lamp),
        temp_data_Lamp[,channel]/max(temp_data_Lamp[as.numeric(rownames(temp_data_Lamp)) %between% c(750,950),channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col="steelblue",
        type="l", lwd=2)  
  
  #plot SRF_datasheet-corrected spectrum
  lines(rownames(temp_data_Datasheet),
        temp_data_Datasheet[,channel]/max(temp_data_Datasheet[as.numeric(rownames(temp_data_Datasheet)) %between% c(750,950),channel], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
        col="darkorange",
        type="l", lwd=2)
  
  text(x=PlotLim[2]*0.95, y=0.95+PlotLimY[2]-PlotLimY[1], "Gi361", font=2)

  #plot peak maxima
  points(x=mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[as.numeric(rownames(temp_data_raw)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5)
  points(x=mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[as.numeric(rownames(temp_data_Datasheet)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[as.numeric(rownames(temp_data_Lamp)) %between% c(750,950),channel], na.rm = TRUE))])),
         y=0.02+PlotLimY[2]-PlotLimY[1], pch="|", cex=1.5, col="steelblue")
  
  #Details (not plotted)
  print(paste0("Gi361 300/500 grating: ",
               round(100*min((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), " to ",
               round(100*max((temp_data_Lamp[,channel][round(as.numeric(rownames(temp_data_Lamp))) %between% c(850,950)]/
                                max(temp_data_Lamp[,channel], na.rm=TRUE)) /
                               (temp_data_Datasheet[,channel][round(as.numeric(rownames(temp_data_Datasheet))) %between% c(850,950)]/
                                  max(temp_data_Datasheet[,channel], na.rm=TRUE)) )), "%"))
  print(paste0(c("Raw: ", "Datasheet: ", "Lamp: "), c(mean(as.numeric(rownames(temp_data_raw)[which(temp_data_raw[,channel] == max(temp_data_raw[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Datasheet)[which(temp_data_Datasheet[,channel] == max(temp_data_Datasheet[,channel], na.rm = TRUE))])),
                                                      mean(as.numeric(rownames(temp_data_Lamp)[which(temp_data_Lamp[,channel] == max(temp_data_Lamp[,channel], na.rm = TRUE))]))
  ), " nm"))
  
  #add wavelength colour bar  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.035,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=0.5 )
  points(200:1500, y=rep(0.5,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=0.5 )
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i", 
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=530, y=1.01,"(b)", cex=1.3)
  
  
  title(main=bquote("300/500 grating"))
  
  }
  
  ##plot legend
  par(new=TRUE)
  par(fig=c(0.71,1,0,1))
  
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n", bty="n")
  
  legend(x=PlotLim[1], y=0.6, lty=1, title="SRF used",legend= sapply(c("None",
                                                                    bquote("S"["total datasheet"]),
                                                                    bquote("S"["total CL6 lamp"])),as.expression), 
         col=c(1,"darkorange", "steelblue"), lwd=c(2,2,2), cex=1.2, bty="n")
  
  dev.off()
}# end plot rel Gi326+Gi361


## Deconvolution of all spectra ---------------------------

# the following block takes a long time; for a rough estimate, decrease the max.runs value

max.runs <- 1000 

{#Gi326
  
  {#150/800 grating
    index150_800 <- grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800")
    
    {#Datasheet
      #load data
      temp_data <- eval(as.symbol(paste0("DataFull_Datasheet_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi326_ALL_Datasheet_",n_components, "cp.csv"), row.names=FALSE)     
      
    }#end Datasheet 2cp
    
    {#Lamp
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_Lamp_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi326_ALL_Lamp_",n_components, "cp.csv"), row.names=FALSE) 
      
    }#end Lamp 2cp
    
    {#raw
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_raw_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi326_ALL_raw_",n_components, "cp.csv"), row.names=FALSE) 
      
    }#end raw 2cp

  }# end grating 150/800 
  
  {#300-500 grating
    index300_500 <- grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau")
    
    {#Datasheet
      #load data
      temp_data <- eval(as.symbol(paste0("DataFull_Datasheet_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_300-500_Gi326_ALL_Datasheet_",n_components, "cp_extrapol.csv"), row.names=FALSE)     
      
    }#end Datasheet 2cp
    
    {#Lamp
      #load data 
      temp_data <- eval(as.symbol(paste0("DataFull_Lamp_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                       paste0("output/Deconvolution_300-500_Gi326_ALL_Lamp_",n_components, "cp.csv"), row.names=FALSE) 
                
    }#end Lamp 2cp
    
    {#raw
      #load data
      temp_data <- eval(as.symbol(paste0("DataFull_raw_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_300-500_Gi326_ALL_raw_",n_components, "cp.csv"), row.names=FALSE) 
      
    }#end raw 2cp
    
  }# end grating 300/500
  
  
}# end Gi326 

{#Gi361
  
  {#150/800 grating
    
    index150_800 <- grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800")
    
    {#Datasheet
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_Datasheet_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi361_ALL_Datasheet_",n_components, "cp.csv"), row.names=FALSE)
      
    }#end Datasheet 2cp
    
    {#Lamp
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_Lamp_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi361_ALL_Lamp_",n_components, "cp.csv"), row.names=FALSE) 
                
    }#end Lamp 2cp
    
    {#raw
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_raw_", index150_800)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_150-800_Gi361_ALL_raw_",n_components, "cp.csv"), row.names=FALSE) 
      
    }#end raw 2cp
    
  }# end grating 150/800
  
  {#300-500 grating 
    
    index300_500 <- grep(xsygNames_Data, pattern = "GiveC")
    
    {#Datasheet
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_Datasheet_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_300-500_Gi361_ALL_Datasheet_",n_components, "cp_extrapol.csv"), row.names=FALSE)
      
    }#end Datasheet 2cp
    
    {#Lamp
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_Lamp_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_300-500_Gi361_ALL_Lamp_",n_components, "cp.csv"), row.names=FALSE)
      
    }#end Lamp 2cp
    
    {#raw
      #load data DS
      temp_data <- eval(as.symbol(paste0("DataFull_raw_", index300_500)))
      temp_data_conv <- data.frame("Wavelength"=row.names(temp_data),
                                   temp_data)
      
      #set limits to be analysed
      LimitsAnalysis_nm <- c(750, 950)  
      LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm) 
      
      #Energy conversion
      temp_data_conv <- convert_Wavelength2Energy(temp_data_conv, digits = 4L, order = FALSE)
      temp_data_conv <- temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]
      temp_data_conv_noBG <- matrix(c(temp_data_conv[,1],
                                      unlist(lapply(2:ncol(temp_data_conv), function(x) temp_data_conv[,x] - temp_data_conv[1,x]))),
                                    ncol=ncol(temp_data_conv))
      
      TestSpectra <- seq(1,ncol(temp_data))
      n_components <- 2
      coeff <- c()
      for (i in TestSpectra){
        
        
        data_fit <- fit_EmissionSpectra(
          #as.matrix(temp_data_conv[temp_data_conv[,1] %between% LimitsAnalysis_eV,]),
          temp_data_conv_noBG,
          frame = i,
          n_components = n_components,
          start_parameters = c(1.36, 1.43#, 1.75
          ),
          sub_negative = 0,
          input_scale = "energy",
          method_control = list(max.runs = max.runs),
          verbose = TRUE,
          plot = FALSE
        )
        
        gc()
        if(is.na(data_fit@data[["data"]][[1]])){
          coeff <- c(coeff, rep(c(NA, NA, NA),n_components))
        } else {
          coeff <- c(coeff, data_fit $data[,c("mu","sigma","C")])
        }
        
        
      }
      
      #library(beepr)
      #beep()
      
      #save summary of peak centre wavelength
      write.csv(matrix(coeff, ncol=n_components, byrow=TRUE),
                paste0("output/Deconvolution_300-500_Gi361_ALL_raw_",n_components, "cp.csv"), row.names=FALSE) 
      
    }#end raw 2cp
    
  }# end grating 300/500
  
  
}# end Gi361



#### Plot example deconvolution | Fig 8  ---------------------------

{ n_components <- 2
  
  pdf(paste0("output/", "Fig8_SRF_RF_deconvolution_Example_Gi326+Gi361_2cp.pdf"), width = 7*2, height = 6.5)
  
  par( mar=c(5,5,3,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #(a)
  {#150-800 grating
    
    #load data
    temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
    temp_data_conv_Datasheet <- data.frame("Wavelength"=row.names(temp_data_Datasheet),
                                           temp_data_Datasheet)
    temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
    temp_data_conv_Lamp <- data.frame("Wavelength"=row.names(temp_data_Lamp),
                                      temp_data_Lamp)
    
    TestSpectra <- seq(1,ncol(temp_data_Datasheet))
    
    #Energy conversion
    temp_data_conv_Datasheet <- convert_Wavelength2Energy(temp_data_conv_Datasheet, digits = 4L, order = FALSE)
    temp_data_conv_Lamp <- convert_Wavelength2Energy(temp_data_conv_Lamp, digits = 4L, order = FALSE)
    
    #Load parameters of Gaussian functions
    PeakPars_Datasheet <- as.matrix(read.csv("output/Deconvolution_150-800_Gi326_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE))
    PeakPars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
    
    #set analysed limits
    LimitsAnalysis_nm <- c(750, 950)  
    LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm)   #  nm -> eV
    
    par(fig=c(0,0.40,0,1))
    
    PlotLim=c(1.27, 1.655)
    PlotLimY <- c(-0.1, 1.1)
    
    #plot SRF_datasheet-corrected spectrum
    channel=100
    spec <- temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    plot(temp_data_conv_Datasheet$Wavelength[temp_data_conv_Datasheet$Wavelength %between% PlotLim],
         spec/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
         col="darkorange",
         type="l", lwd=2,
         xlim=c(PlotLim[1], PlotLim[2]+PlotLim[2]-PlotLim[1]), 
         ylim=c(PlotLimY[1], PlotLimY[2]+PlotLimY[2]-PlotLimY[1]), 
         xaxs="i", xaxt="n", yaxs="i", yaxt="n",
         xlab="Energy (eV)", ylab="Background-corrected RF (a.u.)")  
    
    axis(1, at=seq(1.3, PlotLim[2], 0.1), labels = seq(1.3, PlotLim[2], 0.1))
    axis(2, at=seq(0,PlotLimY[2], 0.5), labels = seq(0,PlotLimY[2], 0.5))
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
            max(spec-PlotBG, na.rm=TRUE)*OneGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
            col="darkorange")  
    }
    
    
    lines(PlotLim,
          rep(PlotBG,2)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="darkorange")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
          (TG + PlotBG)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE), col=1, lty=2)  
    
    abline(v=PlotLim[2])
    axis(1, at=seq(1.3, PlotLim[2], 0.1)+PlotLim[2]-PlotLim[1], labels = seq(1.3, PlotLim[2], 0.1))
    
    abline(h=PlotLimY[2])
    axis(2, at=seq(0,PlotLimY[2], 0.5)+PlotLimY[2]-PlotLimY[1], labels = seq(0,PlotLimY[2], 0.5))
    
    
    #plot SRF_lamp-corrected spectrum
    spec <- temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Lamp$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim]+PlotLim[2]-PlotLim[1],
          spec/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="steelblue",
          type="l", lwd=2)  
    
    lines(PlotLim+PlotLim[2]-PlotLim[1],
          rep(PlotBG,2)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="steelblue")
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
            max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
            col="steelblue")  
    }
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
          (TG + PlotBG)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col=1, lty=2)   
    
    #plot legend
    par(font=2)
    legend(x=PlotLim[2], y=PlotLimY[2], title="Gi326  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2], title="Gi326  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    par(font=1)
    legend(x=PlotLim[2], y=PlotLimY[2], title="  ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Datasheet[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2], title="  ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Lamp[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    
    #Gi361
    #load data
    temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800"))))
    temp_data_conv_Datasheet <- data.frame("Wavelength"=row.names(temp_data_Datasheet),
                                           temp_data_Datasheet)
    temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi361_500LP_RF70_SpecF_150-800"))))
    temp_data_conv_Lamp <- data.frame("Wavelength"=row.names(temp_data_Lamp),
                                      temp_data_Lamp)
    
    TestSpectra <- seq(1,ncol(temp_data_Datasheet))
    
    #Energy conversion
    temp_data_conv_Datasheet <- convert_Wavelength2Energy(temp_data_conv_Datasheet, digits = 4L, order = FALSE)
    temp_data_conv_Lamp <- convert_Wavelength2Energy(temp_data_conv_Lamp, digits = 4L, order = FALSE)
    
    #Load parameters of Gaussian functions
    PeakPars_Datasheet <- as.matrix(read.csv("output/Deconvolution_150-800_Gi361_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE))
    PeakPars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
    
    
    #plot SRF_datasheet-corrected spectrum
    spec <- temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Datasheet$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim],
          spec/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="darkorange",
          type="l", lwd=2)
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
            max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
            col="darkorange")  
    }
    
    lines(PlotLim,
          rep(PlotBG,2)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="darkorange")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
          (TG + PlotBG)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col=1, lty=2)  
    
    
    #plot SRF_lamp-corrected spectrum
    spec <- temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Lamp$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim]+PlotLim[2]-PlotLim[1],
          spec/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="steelblue",
          type="l", lwd=2)
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
            max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
            col="steelblue")  
    }
    
    lines(PlotLim+PlotLim[2]-PlotLim[1],
          rep(PlotBG,2)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="steelblue")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
          (TG + PlotBG)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col=1, lty=2)  
    
    #plot legend
    par(font=2)
    legend(x=PlotLim[2], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title="Gi361  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title="Gi361  ",
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    par(font=1)
    legend(x=PlotLim[2], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title=" ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Datasheet[3*(channel-1)+1,1:n_components]), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title=" ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Lamp[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)


    #add label 
    par(new=TRUE)
    plot(NA,NA,
         xlim=PlotLim,
         ylim=c(0,1),
         xaxs="i",
         xlab="", xaxt="n",
         ylab="", yaxt="n")
    
    text(x=1.29,y=1,"(a)", cex=1.3)
    
    mtext(text=bquote("S"["total datasheet"]~"             "~"S"["total CL6 lamp"]),
          side=3, font=2, adj=0.5, line=0, cex=1.5)
    
    #add title
    par(new=TRUE)
    par(mar=c(5,5,2,1))
    plot(NA,NA,
         xlim=PlotLim,
         ylim=c(0,1),
         xaxs="i",
         xlab="", xaxt="n",
         ylab="", yaxt="n", bty="n")
    
    title(main=bquote("150/800 grating"))
    par(mar=c(5,5,3,1))
    
  }#150-800 grating
  
  #(b)
  {#300-500 grating
    
    #load data
    temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau"))))
    temp_data_conv_Datasheet <- data.frame("Wavelength"=row.names(temp_data_Datasheet),
                                           temp_data_Datasheet)
    temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau"))))
    temp_data_conv_Lamp <- data.frame("Wavelength"=row.names(temp_data_Lamp),
                                      temp_data_Lamp)
    
    TestSpectra <- seq(1,ncol(temp_data_Datasheet))
    
    #Energy conversion
    temp_data_conv_Datasheet <- convert_Wavelength2Energy(temp_data_conv_Datasheet, digits = 4L, order = FALSE)
    temp_data_conv_Lamp <- convert_Wavelength2Energy(temp_data_conv_Lamp, digits = 4L, order = FALSE)
    
    #Load parameters of Gaussian functions
    PeakPars_Datasheet <- as.matrix(read.csv("output/Deconvolution_300-500_Gi326_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE))
    PeakPars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
    
    #set analysed limits
    LimitsAnalysis_nm <- c(750, 950)  
    LimitsAnalysis_eV <- rev(1.23984193*1000 /LimitsAnalysis_nm)   #  nm -> eV
    
    par(new=TRUE)
    par(fig=c(0.40,0.80,0,1))
    
    PlotLim=c(1.27, 1.655)
    PlotLimY <- c(-0.1, 1.1)
    
    #plot SRF_datasheet-corrected spectrum
    channel=300
    
    spec <- temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    plot(temp_data_conv_Datasheet$Wavelength[temp_data_conv_Datasheet$Wavelength %between% PlotLim],
         spec/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
         col="darkorange",
         type="l", lwd=2,
         xlim=c(PlotLim[1], PlotLim[2]+PlotLim[2]-PlotLim[1]), 
         ylim=c(PlotLimY[1], PlotLimY[2]+PlotLimY[2]-PlotLimY[1]), 
         xaxs="i", xaxt="n", yaxs="i", yaxt="n",
         xlab="Energy (eV)", ylab="Background-corrected RF (a.u.)")  
    
    axis(1, at=seq(1.3, PlotLim[2], 0.1), labels = seq(1.3, PlotLim[2], 0.1))
    axis(2, at=seq(0,PlotLimY[2], 0.5), labels = seq(0,PlotLimY[2], 0.5))
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
            max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
            col="darkorange")  
    }
    
    
    lines(PlotLim,
          rep(PlotBG,2)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="darkorange")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
          (TG + PlotBG)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE), col=1, lty=2)  
    
    abline(v=PlotLim[2])
    axis(1, at=seq(1.3, PlotLim[2], 0.1)+PlotLim[2]-PlotLim[1], labels = seq(1.3, PlotLim[2], 0.1))
    
    abline(h=PlotLimY[2])
    axis(2, at=seq(0,PlotLimY[2], 0.5)+PlotLimY[2]-PlotLimY[1], labels = seq(0,PlotLimY[2], 0.5))
    
    
    #plot SRF_lamp-corrected spectrum
    spec <- temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Lamp$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim]+PlotLim[2]-PlotLim[1],
          spec/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="steelblue",
          type="l", lwd=2)  
    
    lines(PlotLim+PlotLim[2]-PlotLim[1],
          rep(PlotBG,2)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col="steelblue")
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
            max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
            col="steelblue")  
    }
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
          (TG + PlotBG)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE),
          col=1, lty=2)  
    
    #plot legend
    par(font=2)
    legend(x=PlotLim[2], y=PlotLimY[2], title="Gi326  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2], title="Gi326  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    par(font=1)
    legend(x=PlotLim[2], y=PlotLimY[2], title="  ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Datasheet[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2], title="  ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Lamp[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    
    #Gi361
    #load data
    temp_data_Datasheet <- eval(as.symbol(paste0("DataFull_Datasheet_", grep(xsygNames_Data, pattern = "GiveC"))))
    temp_data_conv_Datasheet <- data.frame("Wavelength"=row.names(temp_data_Datasheet),
                                           temp_data_Datasheet)
    temp_data_Lamp <- eval(as.symbol(paste0("DataFull_Lamp_", grep(xsygNames_Data, pattern = "GiveC"))))
    temp_data_conv_Lamp <- data.frame("Wavelength"=row.names(temp_data_Lamp),
                                      temp_data_Lamp)
    
    TestSpectra <- seq(1,ncol(temp_data_Datasheet))
    
    #Energy conversion
    temp_data_conv_Datasheet <- convert_Wavelength2Energy(temp_data_conv_Datasheet, digits = 4L, order = FALSE)
    temp_data_conv_Lamp <- convert_Wavelength2Energy(temp_data_conv_Lamp, digits = 4L, order = FALSE)
    
    #Load parameters of Gaussian functions
    PeakPars_Datasheet <- as.matrix(read.csv("output/Deconvolution_300-500_Gi361_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE))
    PeakPars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
    
    #plot SRF_datasheet-corrected spectrum
    spec <- temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Datasheet$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim],
          spec/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="darkorange",
          type="l", lwd=2)
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
            max((spec-PlotBG)[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Datasheet[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
            col="darkorange")  
    }
    
    
    lines(PlotLim,
          rep(PlotBG,2)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="darkorange")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100),
          (TG + PlotBG)/max(spec[temp_data_conv_Datasheet[temp_data_conv_Datasheet$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col=1, lty=2)  
    
    
    #plot SRF_lamp-corrected spectrum
    spec <- temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,channel] 
    PlotBG <- spec[1]
    TG <- TwoGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),1:n_components], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)) *
      max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)
    
    lines(temp_data_conv_Lamp$Wavelength[temp_data_conv_Lamp$Wavelength %between% PlotLim]+PlotLim[2]-PlotLim[1],
          spec/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="steelblue",
          type="l", lwd=2)
    
    #plot deconvoluted individual Gaussians
    for(i in 1:n_components){
      lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
            max((spec-PlotBG)[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)*OneGauss(par= PeakPars_Lamp[3*(channel-1)+(1:3),i], Energy=seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100))/
              max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
            col="steelblue")  
    }
    
    lines(PlotLim+PlotLim[2]-PlotLim[1],
          rep(PlotBG,2)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col="steelblue")
    
    lines(seq(LimitsAnalysis_eV[1],LimitsAnalysis_eV[2],length.out=100)+PlotLim[2]-PlotLim[1],
          (TG + PlotBG)/max(spec[temp_data_conv_Lamp[temp_data_conv_Lamp$Wavelength %between% PlotLim ,]$Wavelength %between% rev(1.23984193*1000/c(750,950))], na.rm=TRUE)+PlotLimY[2]-PlotLimY[1],
          col=1, lty=2)  
    
    #plot legend
    par(font=2)
    legend(x=PlotLim[2], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title="Gi361  ", 
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title="Gi361  ",
           legend=" ",
           bty="n", cex=0.9, xjust=1, yjust=1)
    par(font=1)
    legend(x=PlotLim[2], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title=" ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Datasheet[3*(channel-1)+1,1:n_components]), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    legend(x=PlotLim[2]+PlotLim[2]-PlotLim[1], y=PlotLimY[2]+PlotLimY[2]-PlotLimY[1], title=" ", 
           legend=paste0(round(1.23984193*1000 /PeakPars_Lamp[3*(channel-1)+1,1:n_components] ), " nm"),
           bty="n", cex=0.9, xjust=1, yjust=1)
    
    
    #add label 
    par(new=TRUE)
    par(mar=c())
    plot(NA,NA,
         xlim=PlotLim,
         ylim=c(0,1),
         xaxs="i",
         xlab="", xaxt="n",
         ylab="", yaxt="n")
    
    text(x=1.29,y=1,"(b)", cex=1.3)
    
    mtext(text=bquote("S"["total datasheet"]~"             "~"S"["total CL6 lamp"]),
          side=3, font=2, adj=0.5, line=0, cex=1.5)
    
    #add title
    par(new=TRUE)
    par(mar=c(5,5,2,1))
    plot(NA,NA,
         xlim=PlotLim,
         ylim=c(0,1),
         xaxs="i",
         xlab="", xaxt="n",
         ylab="", yaxt="n", bty="n")
    
    title(main=bquote("300/500 grating"))
    par(mar=c(5,5,3,1))
    
  }#300-500 grating
  
  ##plot legend
  par(new=TRUE)
  par(fig=c(0.70,1,0,1))
  
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n", bty="n")
  
  legend(x=PlotLim[1], y=0.6, legend = c("Measured spectrum", "Fitted peaks", "Sum of fitted peaks"),
         lty=c(1,1,2), lwd=c(2,1,1), cex=1.1, bty="n")
  
  dev.off()
  
}# end plot Gi326+Gi361 2 cp


#### Plot variation in peak position after deconvolution | Fig 9+10 ---------------------------


#~865 nm peak 2cp eV
{pdf(paste0("output/", "Fig9_SRF_RF_deconvolution_Hist_14eV_2cp_Wraw.pdf"), width = 6*1.5, height = 6)
  
  par(mar=c(5,5,1.5,1), cex=1.0, cex.lab=1.3, cex.axis=1.2)
  
  #(a/b)
  #Gi326
  
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_150-800_Gi326_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_150-800_Gi326_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  #set plot limits
  PlotLim <- c(1.30, 1.45) 
  PlotLimY <- c(0, 1400)#1120)
  
  par(fig=c(0,0.5, 0,0.58))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="Fitted peak energy (eV)", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=TRUE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.darkorange)

  #CL6
  hist(PeakPos_Lamp[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.steelblue)

  #raw
  hist(PeakPos_raw[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.black)

  #print interquartile range
  print("150/800 Gi326 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,2][!(PeakPos_Datasheet[,2] %between% PlotLim)])))
  
  print("150/800 Gi326 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,2][!(PeakPos_Lamp[,2] %between% PlotLim)])))
  
  print("150/800 Gi326 raw:")
  print( round(quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,2][!(PeakPos_raw[,2] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,2], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200, title="Gi326  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(b)", cex=1.3)
  
  
  #Gi361
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_150-800_Gi361_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_150-800_Gi361_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  par(new=TRUE)
  par(fig=c(0,0.5, 0.42,1))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=FALSE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.darkorange)

  #Lamp
  hist(PeakPos_Lamp[,2],
    add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("150/800 Gi361 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,2][!(PeakPos_Datasheet[,2] %between% PlotLim)])))
  
  print("150/800 Gi361 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,2][!(PeakPos_Lamp[,2] %between% PlotLim)])))
  
  print("150/800 Gi361 raw:")
  print( round(quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,2][!(PeakPos_raw[,2] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,2], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200, title="Gi361  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(a)", cex=1.3)
  
  title(bquote("150/800 grating"))
  
  
  #(c/d)
  #300/500 grating
  
  #Gi326
  
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_300-500_Gi326_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_300-500_Gi326_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  ##set plot limits
  #PlotLim <- c(1.30, 1.46)
  #PlotLimY <- c(0, 1400)
  
  par(new=TRUE)
  par(fig=c(0.5,1, 0,0.58))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="Fitted peak energy (eV)", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=TRUE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.darkorange)
  
  #Lamp
  hist(PeakPos_Lamp[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("300/500 Gi326 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,2][!(PeakPos_Datasheet[,2] %between% PlotLim)])))
  
  print("300/500 Gi326 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,2][!(PeakPos_Lamp[,2] %between% PlotLim)])))
  
  print("300/500 Gi326 raw:")
  print( round(quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,2][!(PeakPos_raw[,2] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,2], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200, title="Gi326  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(d)", cex=1.3)
  
  
  #Gi361
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_300-500_Gi361_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_300-500_Gi361_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  par(new=TRUE)
  par(fig=c(0.5,1, 0.42,1))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=FALSE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.darkorange)
  
  #Lamp
  hist(PeakPos_Lamp[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,2],
       add=TRUE, breaks = seq(1.3,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("300/500 Gi361 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,2][!(PeakPos_Datasheet[,2] %between% PlotLim)])))
  
  print("300/500 Gi361 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,2][!(PeakPos_Lamp[,2] %between% PlotLim)])))
  
  print("300/500 Gi361 raw:")
  print( round(quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,2], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,2][!(PeakPos_raw[,2] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,2], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,2], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200, title="Gi361  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.035, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                         paste0("Median: ", round(Med_raw,2), " eV"),
                                                                         "",
                                                                         bquote("S"["total datasheet"]),
                                                                         paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                         "",
                                                                         bquote("S"["total CL6 lamp"]),
                                                                         paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(c)", cex=1.3)
  
  title(bquote("300/500 grating"))
  
  
  
  
  dev.off()
}#end plot 2 cp eV

#~910 nm peak 2cp eV
{pdf(paste0("output/", "Fig10_SRF_RF_deconvolution_Hist_13eV_2cp_Wraw.pdf"), width = 6*1.5, height = 6)
  
  par(mar=c(5,5,1.5,1), cex=1.0, cex.lab=1.3, cex.axis=1.2)
  
  #(a/b)
  #Gi326
  
  #PeakPos_Lamp <- matrix(1.23984193*1000 /round(coeff_Lamp, 3), ncol=n_components, byrow=TRUE)[seq(1,3*length(TestSpectra),3),]
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_150-800_Gi326_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_150-800_Gi326_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  #set plot limits
  PlotLim <- c(1.25, 1.40) 
  PlotLimY <- c(0, 1400)
  
  par(fig=c(0,0.5, 0,0.58))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="Fitted peak energy (eV)", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=TRUE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.darkorange)

  #CL6
  hist(PeakPos_Lamp[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.steelblue)

  #raw
  hist(PeakPos_raw[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.black)

  #print interquartile range
  print("150/800 Gi326 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,1][!(PeakPos_Datasheet[,1] %between% PlotLim)])))
  
  print("150/800 Gi326 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,1][!(PeakPos_Lamp[,1] %between% PlotLim)])))
  
  print("150/800 Gi326 raw:")
  print( round(quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,1][!(PeakPos_raw[,1] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,1], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.030, y=PlotLimY[2]-200, title="Gi326  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.030, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(b)", cex=1.3)
  
  
  #Gi361
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_150-800_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_150-800_Gi361_ALL_Datasheet_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_150-800_Gi361_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  par(new=TRUE)
  par(fig=c(0,0.5, 0.42,1))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=FALSE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.darkorange)
  
  #Lamp
  hist(PeakPos_Lamp[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("150/800 Gi361 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,1][!(PeakPos_Datasheet[,1] %between% PlotLim)])))
  
  print("150/800 Gi361 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,1][!(PeakPos_Lamp[,1] %between% PlotLim)])))
  
  print("150/800 Gi361 raw:")
  print( round(quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,1][!(PeakPos_raw[,1] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,1], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.030, y=PlotLimY[2]-200, title="Gi361  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.030, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(a)", cex=1.3)
  
  title(bquote("150/800 grating"))
  
  
  #(c/d)
  #300/500 grating
  
  #Gi326
  
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi326_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_300-500_Gi326_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_300-500_Gi326_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  ##set plot limits
  #PlotLim <- c(1.25, 1.38)
  #PlotLimY <- c(0, 1400)
  
  par(new=TRUE)
  par(fig=c(0.5,1, 0,0.58))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="Fitted peak energy (eV)", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=TRUE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.darkorange)
  
  #Lamp
  hist(PeakPos_Lamp[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("300/500 Gi326 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,1][!(PeakPos_Datasheet[,1] %between% PlotLim)])))
  
  print("300/500 Gi326 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,1][!(PeakPos_Lamp[,1] %between% PlotLim)])))
  
  print("300/500 Gi326 raw:")
  print( round(quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,1][!(PeakPos_raw[,1] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,1], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.031, y=PlotLimY[2]-200, title="Gi326  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.031, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(d)", cex=1.3)
  
  
  #Gi361
  Pars_Lamp <- as.matrix(read.csv("output/Deconvolution_300-500_Gi361_ALL_Lamp_2cp.csv", stringsAsFactors = FALSE))
  PeakPos_Lamp <- Pars_Lamp[seq(1,nrow(Pars_Lamp)-3,3),]
  Pars_Datasheet <- read.csv("output/Deconvolution_300-500_Gi361_ALL_Datasheet_2cp_extrapol.csv", stringsAsFactors = FALSE)
  PeakPos_Datasheet <- Pars_Datasheet[seq(1,nrow(Pars_Datasheet)-3,3),]
  Pars_raw <- read.csv("output/Deconvolution_300-500_Gi361_ALL_raw_2cp.csv", stringsAsFactors = FALSE)
  PeakPos_raw <- Pars_raw[seq(1,nrow(Pars_raw)-3,3),]
  
  par(new=TRUE)
  par(fig=c(0.5,1, 0.42,1))
  
  plot(NA,NA,
       xlim=PlotLim+0,
       ylim=c(PlotLimY[1], PlotLimY[2]),
       yaxs="i",
       xlab="", xaxt="n",
       ylab="Frequency",# yaxt="n"
  )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.05)), labels=FALSE )
  axis(1, at=c(seq(PlotLim[1], PlotLim[2], 0.01)), labels=FALSE, tck=-0.02 )
  
  #Datasheet
  hist(PeakPos_Datasheet[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.darkorange)
  
  #Lamp
  hist(PeakPos_Lamp[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.steelblue)
  
  #raw
  hist(PeakPos_raw[,1],
       add=TRUE, breaks = seq(1.0,1.7,0.003), col=t.black)
  
  #print interquartile range
  print("300/500 Gi361 S_Datasheet:")
  print( round(quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Datasheet[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Datasheet[,1][!(PeakPos_Datasheet[,1] %between% PlotLim)])))
  
  print("300/500 Gi361 S_CL6:")
  print( round(quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_Lamp[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_Lamp[,1][!(PeakPos_Lamp[,1] %between% PlotLim)])))
  
  print("300/500 Gi361 raw:")
  print( round(quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),3))
  print( round(1.23984193*1000 /quantile(PeakPos_raw[,1], c(0, 0.25, 0.50, 0.75, 1), na.rm=TRUE),1))
  print(paste0("# outside x-axis limits: ", length(PeakPos_raw[,1][!(PeakPos_raw[,1] %between% PlotLim)])))
  
  #Datasheet
  Med_Datasheet <- median(PeakPos_Datasheet[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Datasheet,2),
        y=PlotLimY, lty=2, col=t.darkorange, lwd=2)      
  
  #CL6
  Med_Lamp <- median(PeakPos_Lamp[,1], na.rm=TRUE)
  
  lines(x=rep(Med_Lamp,2),
        y=PlotLimY, lty=2, col=t.steelblue, lwd=2)
  
  #raw
  Med_raw <- median(PeakPos_raw[,1], na.rm=TRUE)
  
  lines(x=rep(Med_raw,2),
        y=PlotLimY, lty=2, col=t.black, lwd=2)
  
  #plot legend
  par(font=2)
  legend(x=PlotLim[1]+0.031, y=PlotLimY[2]-200, title="Gi361  ", 
         legend=" ",
         bty="n", cex=0.8, xjust=0.5, yjust=1)
  par(font=1)
  
  legend(x=PlotLim[1]+0.031, y=PlotLimY[2]-200,  title="  ",legend= sapply(c(bquote("No SRF"),
                                                                            paste0("Median: ", round(Med_raw,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total datasheet"]),
                                                                            paste0("Median: ", round(Med_Datasheet,2), " eV"),
                                                                            "",
                                                                            bquote("S"["total CL6 lamp"]),
                                                                            paste0("Median: ", round(Med_Lamp,2), " eV")),as.expression), 
         pch=c(22, NA, NA, 22, NA, NA, 22, NA),
         lty=c(NA, 2, NA, NA, 2, NA, NA, 2),
         col=c(1, t.black, NA, 1, t.darkorange, NA, 1, t.steelblue, NA), 
         pt.bg=c(t.black, NA, NA, t.darkorange, NA, NA, t.steelblue, NA, NA), cex=0.8, xjust=0.5, yjust=1, bty="n") 
  
  
  #add label 
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       #xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  text(x=PlotLim[1]*1.002,y=0.97,"(c)", cex=1.3)
  
  title(bquote("300/500 grating"))
  
  
  
  
  dev.off()
}#end plot 2 cp eV

# Plot Appendix Fig B1: Filter comparison -----------------------------------------------
{pdf(paste0("output/", "FigB1_SRF_Raw_FilterComparison.pdf"), width = 7, height = 6)
  
  par(mar=c(5,5,2,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)

  #150-800
  PlotLim <- c(350,1450)
  
  
  #load data from 500LP measurement
  temp_data <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800"))))
  
  plot(row.names(temp_data),
       temp_data[,30],
       type="l",
       xlim=PlotLim,
       ylab="Background-corrected RF (cts/1.2 Gy)",  #source dose rate * channel length = 0.061 Gy/s * 19 s
       xlab="Wavelength (nm)") 
  
  
  #load data from 850LP measurement
  temp_data <- eval(as.symbol(paste0("DataFull_raw_", grep(xsygNames_Data, pattern = "Gi326_850LP_RF70_SpecF_150-800"))))
  
  #plot
  lines(row.names(temp_data),
        temp_data[,5], col=2)
  
  legend("topright",  lty=1, title="Filter", legend=c("500LP", "850LP"), col=c(1,2), cex=1.2)
  
  #mark boundaries of first-order signal
  abline(v=480, lty=2, col="darkgrey")
  abline(v=480*2, lty=2, col="darkgrey")
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.05,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=2 )
  
  dev.off()
}
