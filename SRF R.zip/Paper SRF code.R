#The following code and associated data accompany the manuscript 
# "Technical note: Wavelength calibration and spectral sensitivity correction of luminescence measurements for dosimetry applications tested on the IR-RF of K-feldspar" (2022) by
# Mariana Sontag-Gonzalez, Dirk Mittelstrass, Sebastian Kreutzer, Markus Fuchs
# Contact: Mariana.Sontag-Gonzalez@geogr.uni-giessen.de



# General ---------------------
{ library(Luminescence)
  library(data.table)
  library(dplyr)
  
  source('nm2rgb.R')
  
  #function to get local maxima              ##by https://stackoverflow.com/users/5614268/evan-friedland
  inflect <- function(x, threshold = 1){    
    up   <- sapply(1:threshold, function(n) c(x[-(seq(n))], rep(NA, n)))
    down <-  sapply(-1:-threshold, function(n) c(rep(NA,abs(n)), x[-seq(length(x), length(x) - abs(n) + 1)]))
    a    <- cbind(x,up,down)
    list(minima = which(apply(a, 1, min) == a[,1]), maxima = which(apply(a, 1, max) == a[,1]))
  }
  
  
  #function to obtain wavelength once wavelength-calibration parameters are set
  Pixel2Wavelength <- function(pixel=1:1024, WlCalPars=WlCalPars) {
    WlCalPars$x3*pixel^3 + WlCalPars$x2*pixel^2 + WlCalPars$x*pixel^1 + WlCalPars$n}
  
}



# Wavelength calibration -------------------------------------------------------


LampPeaks_ExpectedLocations <- data.frame("Element"=c("Hg", 
                                                      "Hg", 
                                                      "Y", "Hg", "Eu", "Eu",
                                                      "Eu", "Eu", "Eu", "Eu"),
                                          "Wavelength"=c(404.7, #could also be Tb at 403.3 nm
                                                         435.8, #could also be Tb at 432.6 nm
                                                         488.4, 546.1, 583.1, 617.3, 
                                                         643.8, 664.5, 707.7, 758.4))

{ pdf(paste0("output/", "Fig2_FluorescentLamp_SpecPeaks_ForWavelengthCalib_150-800gr_165+300-500gr_260.pdf"), 
      width = 14, height = 6*1.55)
  
  par(mar=c(5,7,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  
  #(a) 150/800 grating
  par(fig=c(0,0.6,0.45,1))
  
  Signal <- read.csv( "data/Wavelength calibration/White light/WhiteLight_150-800grating_165.csv", stringsAsFactors = FALSE)
  BG     <- read.csv( "data/Wavelength calibration/White light/BG_150-800grating_165.csv", stringsAsFactors = FALSE)
  
  plot(Signal$Signal-BG$Signal, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,80000),
       xlab="", #"Pixel"
       ylab="", log="y",
       las=2
  )
  axis(1, at=c(1,1:5*1024/4), label=FALSE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected \n signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  n=10 #look for maxima within pixel ranges of length n
  max <- lapply(1:n, function(x) inflect(Signal$Signal-BG$Signal, threshold = x)$maxima)
  
  ##plot all peaks
  #  points( x=(0:1024)[max[[n]]][1:10], y=(Signal$Signal-BG$Signal)[max[[n]]][1:10], pch = 16, col = t.red, cex = 1)
  
  #visually determine which peaks corresponds to known emissions (unknown peaks are labelled 'NA')

  
  peaks <- c( NA, NA,
              LampPeaks_ExpectedLocations$Wavelength[2], NA, 
              LampPeaks_ExpectedLocations$Wavelength[3],
              LampPeaks_ExpectedLocations$Wavelength[4],
              LampPeaks_ExpectedLocations$Wavelength[5],
              LampPeaks_ExpectedLocations$Wavelength[6], NA, NA,
              LampPeaks_ExpectedLocations$Wavelength[9],
              LampPeaks_ExpectedLocations$Wavelength[10], NA, 
              2*LampPeaks_ExpectedLocations$Wavelength[1],
              2*LampPeaks_ExpectedLocations$Wavelength[2], NA,
              2*LampPeaks_ExpectedLocations$Wavelength[3], NA,
              2*LampPeaks_ExpectedLocations$Wavelength[4],
              2*LampPeaks_ExpectedLocations$Wavelength[5],
              2*LampPeaks_ExpectedLocations$Wavelength[6], NA,
              3*LampPeaks_ExpectedLocations$Wavelength[2], NA, rep(NA, 6)          
  )
  
  #check that you are considering all peaks
  length(peaks) == length(max[[n]])
  
  points( x=(1:1024)[max[[n]]][!is.na(peaks)], y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)], pch = 16, col = 2, cex = 1)
  
  lines(Signal$Signal-BG$Signal)
  
  text(x=(1:1024)[max[[n]]][!is.na(peaks)],
       y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)]*2,
       labels= round(peaks[!is.na(peaks)]), cex=0.8 )
  legend("topright", pch=16, col=2, legend="Signal maxima (nm)")
  
  temp_data <- data.frame("x"=(0:1023)[max[[n]]][!is.na(peaks)] ,
                          "y"=peaks[!is.na(peaks)])
  
  text(x=0,y=55000,"(a)", cex=1.3)
  
  #(b) 
  par(new=TRUE)
  par(fig=c(0.6,1,0.45,1))
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="", #"Pixel"
       ylab="", col=NA)
  axis(1, at=c(1,1:5*1024/4), labels = FALSE)
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  points(temp_data, pch=16, col=2)
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800 <- WlCalPars_lm
  
  lines(0:1024, Pixel2Wavelength(0:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1390,"(b)", cex=1.3)
  
  
  #(c) 300/500 grating
  par(new=TRUE)
  par(fig=c(0,0.6,0,0.55))
  
  Signal <- read.csv( "data/Wavelength calibration/White light/WhiteLight_300-500grating_260.csv", stringsAsFactors = FALSE)
  BG     <- read.csv( "data/Wavelength calibration/White light/BG_300-500grating_260.csv", stringsAsFactors = FALSE)
  
  plot(Signal$Signal-BG$Signal, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,80000), 
       xlab="Pixel", 
       ylab="", log="y", las=2
  )
  axis(1, at=c(1,1:5*1024/4), label=TRUE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected \n signal (cts/0.05 s)    ", cex=1.5, side=2, line=4.5)
  
  n=10
  max <- lapply(1:n, function(x) inflect(Signal$Signal-BG$Signal, threshold = x)$maxima)
  
  ##plot all peaks
  #  points( x=(0:1024)[max[[n]]][1:10], y=(Signal$Signal-BG$Signal)[max[[n]]][1:10], pch = 16, col = t.red, cex = 1)
  
  #visually determine which peaks corresponds to known emissions (unknown peaks are labelled 'NA')
  peaks <- c(LampPeaks_ExpectedLocations$Wavelength[5],
             LampPeaks_ExpectedLocations$Wavelength[6],
             LampPeaks_ExpectedLocations$Wavelength[7],
             LampPeaks_ExpectedLocations$Wavelength[8], NA,
             LampPeaks_ExpectedLocations$Wavelength[9], NA, NA, 
             LampPeaks_ExpectedLocations$Wavelength[10], NA, NA, NA, 
             2*LampPeaks_ExpectedLocations$Wavelength[1], NA, NA, NA, NA, NA, NA, 
             2*LampPeaks_ExpectedLocations$Wavelength[2], rep(NA, 6), 
             2*LampPeaks_ExpectedLocations$Wavelength[3], rep(NA, 7))
  
  #check that you are considering all peaks
  length(peaks) == length(max[[n]])
  
  points( x=(1:1024)[max[[n]]][!is.na(peaks)], y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)], pch = 16, col = 2, cex = 1)
  
  lines(Signal$Signal-BG$Signal)
  
  text(x=(1:1024)[max[[n]]][!is.na(peaks)],
       y=(Signal$Signal-BG$Signal)[max[[n]]][!is.na(peaks)]*2,
       labels= round(peaks[!is.na(peaks)]), cex=0.8 )
  legend("topright", pch=16, col=2, legend="Signal maxima (nm)")
  
  temp_data <- data.frame("x"=(0:1023)[max[[n]]][!is.na(peaks)] ,
                          "y"=peaks[!is.na(peaks)])
  
  text(x=0,y=55000,"(c)", cex=1.3)
  
  
  #(D) 
  par(new=TRUE)
  par(fig=c(0.6,1,0,0.55))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(550,1100),
       xlab="Pixel", ylab="", col=NA)
  axis(1, at=c(1,1:5*1024/4))
  axis(2, at=seq(500,1500,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  points(temp_data, pch=16, col=2)
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n), digits=3))~"     "), cex=1.1)
  
  #save parameters to use later
  WlCalPars_lm_300_500 <- WlCalPars_lm
  
  lines(0:1024, Pixel2Wavelength(0:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1095,"(d)", cex=1.3)
  
  dev.off()
}





#  Alternative wavelength calibrations -----------------------------------------


## by Hg(Ar) lamp --------------------------------------------------------------
{ pdf(paste0("output/", "FigA1_Hg-Ar_SpecPeaks_ForWavelengthCalib_150-800gr_165.pdf"), width = 14, height = 6)
  
  par(mar=c(5,6,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  par(fig=c(0,0.6,0,1))
  
 
  Data <- read.csv( "data/Wavelength calibration/Hg-Ar lamp/Hg-0,001s-closedSlit.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  BG <- read.csv(   "data/Wavelength calibration/Hg-Ar lamp/BG_0,001s-165nm_closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  
  Signal <- Data$Intensity..counts.-BG$Intensity..counts.
  
  #(a)
  plot(
    Signal, type="l",
    xaxt="n", yaxs="i",
    # xlim=c(1,1024), 
    ylim=c(100,100000),
    xlab="Pixel",
    ylab="", log="y",
    las=2,
    col="darkred"
  )
  axis(1, at=c(1,1:5*1024/4), label=TRUE)
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  mtext("Background-corrected signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  #get peaks
  n=10
  max <- lapply(1:n, function(x) inflect(Signal,
                                         threshold = x)$maxima)
  ##plot all identified peak positions
  #points( x=(1:1024)[max[[n]]], y=Signal[max[[n]]], pch = 1, col = 1, cex = 1)
  
  
  Pixel_peaks <- (1:1024)[max[[n]]]
  
  #define expected spectral lines based on lamp manufacturer specifications
  HgAr_lines <- c(253.7, 302.2, 312.6, 334.0, 365.0, 404.7, 435.8, 546.1, mean(c(577.0, 579.0)))
  
  #manually define which peaks correspond to which wavelengths
  Wavelengths_peaks <-c(1*HgAr_lines[7],
                        2*HgAr_lines[1],
                        1*HgAr_lines[8:9],
                        2*HgAr_lines[3:5],
                        3*HgAr_lines[1],
                        2*HgAr_lines[6:7],
                        3*HgAr_lines[2:3],
                        NA,
                        4*HgAr_lines[1],
                        NA,
                        mean(2*HgAr_lines[8],3*HgAr_lines[5]),
                        2*HgAr_lines[9],
                        NA,
                        mean(4*HgAr_lines[2], 3*HgAr_lines[6]),
                        #4*HgAr_lines[3],
                        5*HgAr_lines[1],
                        3*HgAr_lines[7],
                        4*HgAr_lines[4],
                        NA
  )
  
  #check that you are considering all peaks
  length(Pixel_peaks) == length( Wavelengths_peaks)
  
  #define colours for plot
  OrderCol <-  c("red", "goldenrod1", "springgreen3", "darkorange", "steelblue") 
  
  points(x=(1:1024)[max[[n]]][!is.na(Wavelengths_peaks)], y=Signal[max[[n]]][!is.na(Wavelengths_peaks)],
         col = OrderCol[c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)][!is.na(Wavelengths_peaks)],
         pch = 16, cex = 1)
  
  
  lines(Signal)
  
  temp_data <- data.frame("x"=Pixel_peaks ,
                          "y"=Wavelengths_peaks)
  
  text(x=0,y=80000,"(a)", cex=1.3)
  
  
  #(b) 
  par(new=TRUE)
  par(fig=c(0.6,1,0,1))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",#xaxs="i", yaxs="i",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab="", 
       col=OrderCol[c(1,2,rep(1,2),rep(2,3),3,rep(2,2),rep(3,2),NA, 4,NA,3,2,NA,3,5,3,4, NA)]
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  
  #Get parameter sign
  PosNeg <- WlCalPars_lm>0
  
  #print calibration function
  mtext(bquote("     f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800_Hg <- WlCalPars_lm
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm), col=1)
  
  text(x=30,y=1400,"(b)", cex=1.3)
  
  legend("bottomright",  col=OrderCol, 
         pch=16, legend=c("First", "Second", "Third", "Fourth", "Fifth"), title="Signal order")
  
  dev.off()
}


## by solar simulator peaks (Fig A2) -------------------------------------------
{ pdf(paste0("output/", "FigA2_SLS_SpecPeaks_ForWavelengthCalib_150-800gr_165.pdf"), width = 14, height = 6)
  
  par(mar=c(5,6,1.5,1.5), cex=1.2, cex.lab=1.2, cex.axis=1.1)
  
  par(fig=c(0,0.6,0,1))
  
  Data_IR    <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_IR_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_red   <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_red_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_amber <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_amber_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_green <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_green_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_blue  <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_blue_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  Data_UV    <- read.csv( "data/Wavelength calibration/Solar simulator/SLS_UV_0,001s_165_Closed.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  BG         <- read.csv( "data/Wavelength calibration/Solar simulator/BG_0,001s_165.csv", stringsAsFactors = FALSE, skip=9, header=TRUE, sep=";")
  
  Signal_IR    <- Data_IR$Intensity..counts.- BG$Intensity..counts.
  Signal_red   <- Data_red$Intensity..counts.- BG$Intensity..counts.
  Signal_amber <- Data_amber$Intensity..counts.- BG$Intensity..counts.
  Signal_green <- Data_green$Intensity..counts.- BG$Intensity..counts.
  Signal_blue  <- Data_blue$Intensity..counts.- BG$Intensity..counts.
  Signal_UV    <- Data_UV$Intensity..counts.- BG$Intensity..counts.
  
  #(a)
  plot(Signal_IR, type="l",
       xaxt="n", yaxs="i",
       xlim=c(1,1024), ylim=c(10,10000),
       xlab="Pixel",
       ylab="", log="y",
       las=2,
       col="darkred"
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=c(seq(1,10,1),seq(10,100,10),seq(100,1000,100),seq(1000,10000,1000),seq(10000,100000,10000)), labels=FALSE, tck=-0.02)
  
  lines(Signal_IR, col="darkred")
  lines(Signal_red, col="red")
  lines(Signal_amber, col="goldenrod2")
  lines(Signal_green, col="springgreen2")
  lines(Signal_blue, col="blue")
  lines(Signal_UV, col="lightblue")
  
  mtext("Background-corrected signal (cts/0.001 s)    ", cex=1.5, side=2, line=4.5)
  
  legend("topright", lty=1, col=c("darkred", "red", "goldenrod2", "springgreen2", "blue", "lightblue"), title="LED",
         legend=c("IR", "red", "amber", "green", "blue", "UV"))
  
  #get peak positions
  n=10
  max_IR <- lapply(1:n, function(x) inflect(Signal_IR[Signal_IR>30],
                                            threshold = x)$maxima)
  max_red <- lapply(1:n, function(x) inflect(Signal_red[Signal_red>30],
                                             threshold = x)$maxima)
  max_amber <- lapply(1:n, function(x) inflect(Signal_amber[Signal_amber>30],
                                               threshold = x)$maxima)
  max_green <- lapply(1:n, function(x) inflect(Signal_green[Signal_green>30],
                                               threshold = x)$maxima)
  max_blue <- lapply(1:n, function(x) inflect(Signal_blue[Signal_blue>30],
                                              threshold = x)$maxima)
  max_UV <- lapply(1:n, function(x) inflect(Signal_UV[Signal_UV>30],
                                            threshold = x)$maxima)
  
  points( x=(1:1024)[Signal_IR>30][max_IR[[n]]], y=Signal_IR[Signal_IR>30][max_IR[[n]]], pch = 16, col = "darkred", cex = 1)
  
  points( x=(1:1024)[Signal_red>30][max_red[[n]]], y=Signal_red[Signal_red>30][max_red[[n]]], pch = 16, col = "red", cex = 1)
  
  points( x=(1:1024)[Signal_amber>30][max_amber[[n]]], y=Signal_amber[Signal_amber>30][max_amber[[n]]], pch = 16, col = "goldenrod2", cex = 1)
  
  points( x=(1:1024)[Signal_green>30][max_green[[n]]], y=Signal_green[Signal_green>30][max_green[[n]]], pch = 16, col = "springgreen2", cex = 1)
  
  points( x=(1:1024)[Signal_blue>30][max_blue[[n]]], y=Signal_blue[Signal_blue>30][max_blue[[n]]], pch = 16, col = "blue", cex = 1)
  
  points( x=(1:1024)[Signal_UV>30][max_UV[[n]]], y=Signal_UV[Signal_UV>30][max_UV[[n]]], pch = 16, col = "lightblue", cex = 1)
  
  
  Pixel_peaks <- c((1:1024)[Signal_IR>30][max_IR[[n]]],       #IR
                   (1:1024)[Signal_red>30][max_red[[n]]],     #red
                   (1:1024)[Signal_amber>30][max_amber[[n]]], #amber
                   (1:1024)[Signal_green>30][max_green[[n]]], #green
                   (1:1024)[Signal_blue>30][max_blue[[n]]],   #blue
                   (1:1024)[Signal_UV>30][max_UV[[n]]]       #UV
                   
  )
  
  #manually assign peak to LED wavelength
  Wavelengths_LEDs <- c(850,        #IR
                        625, 2*625, #red
                        590, 2*590, #amber
                        rep(523,5), 2*523, #green
                        462, 2*462, #blue
                        2*365       #UV
  )
  
  #check all peaks were considered
  length(Pixel_peaks) == length( Wavelengths_LEDs)
  
  temp_data <- data.frame("x"=Pixel_peaks ,
                          "y"=Wavelengths_LEDs)
  
  text(x=0,y=7800,"(a)", cex=1.3)
  
  
  #(b) 
  par(new=TRUE)
  par(fig=c(0.6,1,0,1))
  
  #fit with 3-degree polynomial
  WlCalPars_lm <- transpose(as.data.frame(coefficients(lm(y ~ x + I(x^2) + I(x^3), data= temp_data ))))
  colnames(WlCalPars_lm) <- c("n", "x", "x2", "x3")
  
  plot(temp_data,
       pch=16,
       las=2,
       xaxt="n",#xaxs="i", yaxs="i",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab="", 
       col=c("darkred", rep("red",2), rep("goldenrod2",2), rep("springgreen2", 6),
             rep("blue", 2), rep("lightblue", 1)))
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Peak wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  PosNeg <- WlCalPars_lm>0
  
  
  mtext(bquote("f(x) ="~.(signif(WlCalPars_lm$x3, digits=2))*"*x"^3~.(ifelse(PosNeg[,"x2"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x2), digits=2))*"*x"^2~.(ifelse(PosNeg[,"x"],"+", "-"))
               ~.(signif(abs(WlCalPars_lm$x), digits=2))*"*x"~.(ifelse(PosNeg[,"n"],"+", "-"))~.(signif(abs(WlCalPars_lm$n),
                                                                                                        digits=3))~"     "), cex=1.1)
  #save parameters to use later
  WlCalPars_lm_150_800_sls <- WlCalPars_lm
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm), col=1)

  text(x=30,y=1400,"(b)", cex=1.3)
  
  dev.off()
}


## Plot Fig 3: comparison of wavelength calibration methods -------------------
{pdf(paste0("output/", "Fig3_WavelengthCalibrationComparison.pdf"), width = 7, height = 6)
  
  par(mar=c(5,6,1,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  plot(NA,NA,
       pch=16,
       las=2,
       xaxt="n",
       xlim=c(1,1024), ylim=c(380,1400),
       xlab="Pixel", ylab=""
  )
  axis(1, at=c(1,1:4*1024/4))
  axis(2, at=seq(200,2000,50), labels = FALSE, tck=-0.01)
  mtext("Wavelength (nm)", cex=1.5, side=2, line=4)
  
  
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800), col=1)
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg), col=2)
  lines(1:1024, Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls), col=4)
  
  
  legend("topleft",  col=c(1,2,4), 
         lty=1, legend=c("Fluorescent lamp", 
                         "Hg(Ar) lamp", 
                         "'SLS' LEDs"), title="Calibration method")
  
  #inset showing calibrations in relation to Hg)AR) lamp calibration
  par(new=TRUE)
  par(fig=c(0.48,1,0.11,0.57), mgp=c(1.6,0.5,0))
 # par(fig=c(0.15,0.65,0.5,1), mgp=c(2,1,0))
  
  plot(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
       Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)/
         Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
       type="l", col=2,
       ylim=c(0.94,1.08), yaxs="i",
       xaxt="n", yaxt="n",
       xlab="Wavelength (nm)", ylab="Wavelength relative to      \n Hg(Ar) calibration (a.u.)     ", 
       cex.lab=1)
  axis(1, at=seq(400,1400,400), cex.axis=1)
  axis(1, at=seq(400,1400,100), labels = FALSE, tck=-0.02)
  axis(2, at=seq(0.94,1.08,0.06), cex.axis=1)
  axis(2, at=seq(0.94,1.08,0.02), labels = FALSE, tck=-0.02)
  
  lines(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800)/
          Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        col=1)
  lines(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)/
          Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg),
        col=4)

  dev.off()  
  
}

Differences <- data.frame("WhiteLight_Hg" = abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)),
                          "WhiteLight_sls"= abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)),
                          "Hg_sls"        = abs(Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg)  - Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_sls)))

print(paste0("Maximum difference between fluorescent white light and Hg(Ar) lamp calibrations in the range 500-1000 nm is: ",
             round(max(Differences$WhiteLight_Hg[Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800) %between% c(500,1000) &
                                                 Pixel2Wavelength(1:1024, WlCalPars=WlCalPars_lm_150_800_Hg) %between% c(500,1000)]
                       )), " nm."))


# Efficiency calibration  ------------------------------------------------------


## Datasheet SRF ---------------------------------------------------------------


## Load datasheet sensitivity
#a) longpass filter 500 nm
LongPassFilter500_T  <- read.csv("data/Datasheets/Filter LP 500 nm.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #https://www.thorlabs.com/newgrouppage9.cfm?objectgroup_ID=918

#b) fused silica lens (1x magnification) at entry of fibre optic bundle
AttachmentOptics     <- read.csv("data/Datasheets/RF1xOSL2x_lens.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") # #48-836 https://www.edmundoptics.com.au/f/uv-fused-silica-double-convex-dcx-lenses/12412/

#c) quartz fibre optic bundle
Fibre_T              <- read.csv("data/Datasheets/Fibre Optic Quartz T.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #https://qd-europe.com/pl/en/product/fiber-optic-light-sources/
Fibre_T$Transmittance <- (sqrt(Fibre_T$Transmittance))^3#dataheet is given for 2 m, correct for true length of 3 m

#d) coating of spectrometer optics
SpecCoating_R        <- read.csv("data/Datasheets/SR163 coatings.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #Sheet from LexFlash

#e) diffraction grating 
Grating300_500_QE    <- read.csv("data/Datasheets/Grating 300-500.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM")  # Uncertainty: 3%; https://www.gratinglab.com/Products/Product_Tables/Efficiency/Efficiency.aspx?catalog=53-*-270R
Grating300_500_QE$QE <- rowMeans(Grating300_500_QE[,c("p_plane", "s_plane")], na.rm = FALSE, dims = 1) #get mean of s- and p-planes since our light is not polarized

Grating150_800_QE    <- read.csv("data/Datasheets/Grating 150-800.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM")  # Uncertainty: 3%; https://www.gratinglab.com/Products/Product_Tables/Efficiency/Efficiency.aspx?catalog=53-*-426R
Grating150_800_QE$QE <- rowMeans(Grating150_800_QE[,c("p_plane", "s_plane")], na.rm = FALSE, dims = 1)  #get mean of s- and p-planes since our light is not polarized

#f) CCD camera
CCDCameraQE          <- read.csv("data/Datasheets/DU920P BU -100degC QE.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #Sheet from LexFlash

#calculate SRFs
PlotX <- 200:1400
SRF_datasheet_150_800 <- data.frame("Wavelength"=PlotX,
                                    "Factor"=approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
                                      approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
                                      approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
                                      approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y)

SRF_datasheet_300_500 <- data.frame("Wavelength"=PlotX,
                                    "Factor"=approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
                                      approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
                                      approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
                                      approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
                                      approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y)


{pdf(paste0("output/", "Fig4_SRF_Datasheet_wIndiv_500LP_150-800(A)+_300-500(B).pdf"), width = 7*2, height = 6)
  
  
  par(mfcol=c(1,2), mar=c(5,5,1,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  PlotLim <- c(300,1300)
  PlotX <- 200:1400
  
  #(a)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1.1),
       xlab="Wavelength (nm)",
       ylab="Relative transmission")
  
  lines(LongPassFilter500_T, col="darkgrey")
  lines(AttachmentOptics$Wavelength, AttachmentOptics$Transmission, col="darkgrey")
  lines(x=max(AttachmentOptics$Wavelength):max(PlotX), y= rep(AttachmentOptics$Transmission[length(AttachmentOptics$Transmission)], length(max(AttachmentOptics$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  lines(Fibre_T, col="darkgrey")
  lines(SpecCoating_R, col="darkgrey")
  lines(Grating150_800_QE$Wavelength, Grating150_800_QE$QE, col="darkgrey")
  lines(x=200:min(Grating150_800_QE$Wavelength), y=  rep(Grating150_800_QE$QE[1], length(200:min(Grating150_800_QE$Wavelength))), lty=2, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  lines(x=max(CCDCameraQE$Wavelength):max(PlotX), y= rep(CCDCameraQE$QE[length(CCDCameraQE$QE)], length(max(CCDCameraQE$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  text(x=1307, y=0.92, labels="A")
  text(x=300,  y=1.03, labels="B")
  text(x=1307, y=0.22, labels="C")
  text(x=300,  y=0.88, labels="D")
  text(x=1307, y=0.43, labels="E")
  text(x=1307, y=0.05, labels="F")
  
  #plot SRF
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y
        ,
        col=1, lwd=2, lty=2
  )
  
  #plot SRF in wavelength range of interpolation
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y,
        col=1, lwd=2, lty=1
  )
  
  legend("topright", legend=sapply(c(bquote("Optical component"), bquote("S"["total datasheet"])),as.expression)
         , col=c("darkgrey", "black"), lty=1, lwd=c(1,2), bty="n")
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=305,y=1,"(a)", cex=1.3)
  
  
  
  
  #(b)
  PlotLim <- c(300,1000)
  PlotX <- 200:1400
  
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1.1),
       xlab="Wavelength (nm)",
       ylab="Relative transmission")
  
  lines(LongPassFilter500_T, col="darkgrey")
  lines(AttachmentOptics$Wavelength, AttachmentOptics$Transmission, col="darkgrey")
  lines(x=max(AttachmentOptics$Wavelength):max(PlotX), y= rep(AttachmentOptics$Transmission[length(AttachmentOptics$Transmission)], length(max(AttachmentOptics$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  
  lines(Fibre_T, col="darkgrey")
  lines(SpecCoating_R, col="darkgrey")
  lines(Grating300_500_QE$Wavelength, Grating300_500_QE$QE, col="darkgrey")
  lines(x=200:min(Grating300_500_QE$Wavelength), y=  rep(Grating300_500_QE$QE[1], length(200:min(Grating300_500_QE$Wavelength))), lty=2, col="darkgrey")
  lines(x=max(Grating300_500_QE$Wavelength):max(PlotX), y= rep(Grating300_500_QE$QE[length(Grating300_500_QE$QE)], length(max(Grating300_500_QE$Wavelength):max(PlotX))), lty=2, col="darkgrey")
  lines(CCDCameraQE, col="darkgrey")
  
  text(x=1000, y=0.95, labels="A")
  text(x=300,  y=1.03, labels="B")
  text(x=1000, y=0.48, labels="C")
  text(x=300,  y=0.88, labels="D")
  text(x=1000, y=0.38, labels="E")
  text(x=1000, y=0.09, labels="F")
  
  #plot SRF (extrapolating nearest point)
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y
        ,
        col=1, lwd=2, lty=2
  )
  
  #plot SRF in wavelength range of interpolation
  lines(PlotX,
        approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:1)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:1)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:1)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:1)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:1)$y,
        col=1,
        lwd=2, lty=1
  )
  
  
  legend("topright", legend=sapply(c(bquote("Optical component"), bquote("S"["total datasheet"])),as.expression),
         col=c("darkgrey", "black"), lty=1, lwd=c(1,2), bty="n")
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=305,y=1,"(b)", cex=1.3)
  
  dev.off()
}



## Calibration lamp measurement for SRF ----------------------------------------

#Load lamp calibration
CL6_Irr <- read.csv("data/Datasheets/CL6 Irradiance fromCD.csv", stringsAsFactors = FALSE, header=TRUE, fileEncoding="UTF-8-BOM") #From Bentham calibration CD

#Calculate relative photon emission
CL6_Irr$Energy <- 1239.84193 / CL6_Irr$Wavelength  # Energy = Planck constant * light speed / wavelength  = 4.13566769692e-15 eV*s * 299792458e+9 nm/s / wavelength in nm
CL6_Irr$Intensity <- CL6_Irr$Irradiance..mW.m.2.nm.1. # in mW * m^2 * nm^-1, which is equivalent to 10^-3 * 6.24 * 10^18 eV * s^-1 * m^2 * nm^-1
CL6_Irr$Rel_Photon_Emission <- 6.24e+15 * CL6_Irr$Intensity/CL6_Irr$Energy  #units: (eV * s^-1 * m^-2 * nm^-1) / eV, equivalent to s^-1 * m^-2 * nm^-1

#Load lamp measurement
#150-800 grating
temp_1 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_1_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
temp_2 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_2_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
temp_3 <- read.csv("data/Lamp measurements/150-800 grating/CL6+500LP_3_0,001s_165nm_Open.csv", skip=9, header=TRUE, sep=";")
BG_1   <- read.csv("data/Lamp measurements/150-800 grating/BG_0,001s_165nm.csv", skip=9, header=TRUE, sep=";")
CL6_150_800_500LP <- data.frame("Wavelength"= Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800), 
                                "Intensity" = rowMeans(data.frame(temp_1$Intensity..counts.,
                                                                  temp_2$Intensity..counts.,
                                                                  temp_3$Intensity..counts.))-
                                  BG_1$Intensity..counts.
)

#300-500 grating
temp_1 <- read.csv("data/Lamp measurements/300-500 grating/CL6-1_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
temp_2 <- read.csv("data/Lamp measurements/300-500 grating/CL6-2_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
temp_3 <- read.csv("data/Lamp measurements/300-500 grating/CL6-3_0.01s-1xRF+500LP-dim.csv", skip=9, header=TRUE, sep=";")
BG_1   <- read.csv("data/Lamp measurements/300-500 grating/BG_RF1x_0,01s_1.csv", skip=9, header=TRUE, sep=";")
CL6_300_500_500LP <- data.frame("Wavelength"= Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500), 
                                "Intensity" = rowMeans(data.frame(temp_1$Intensity..counts.,
                                                                  temp_2$Intensity..counts.,
                                                                  temp_3$Intensity..counts.))-
                                  BG_1$Intensity..counts.
)

{ pdf(paste0("output/", "Fig5_SRF_CalibLamp_FullLength2.pdf"), width = 6*2, height = 6, bg="white")
  
  par( mar=c(5,5,1,2), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #150-800
  PlotLim=c(c(300,1450))
  PlotX <- 300:1500
  
  par( fig=c(0,0.5,0.4,1))
  plot(PlotX,     
       approx(x=CL6_Irr$Wavelength,
              y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y/
         max(approx(x=CL6_Irr$Wavelength,
                    y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y),
       type="l", lty=2, 
       xaxs="i",
       bty="n", xaxt="n",  yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       xlab="", ylab="Signal (a.u.)")
  
  axis(side=1, at=seq(200,1600,200), labels=FALSE)
  axis(side=2, at=c(0,0.5,1))
  
  legend("bottomright", legend=c("Emitted", "Measured"), lty=c(2,1), cex=1.2)
  
  
  par(new=TRUE, fig=c(0,0.5,0,0.55))
  plot(CL6_150_800_500LP$Wavelength, #[CL6_150_800_500LP$Wavelength %between% c(300,960)],
       CL6_150_800_500LP$Intensity/ #[CL6_150_800_500LP$Wavelength %between% c(300,960)]/
         max(CL6_150_800_500LP$Intensity),
       type="l", lty=1, 
       xaxs="i",
       bty="n",  xaxt="n", yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       col="darkgrey",
       xlab="Wavelength (nm)", ylab="Signal (a.u.)")
  
  lines(CL6_150_800_500LP$Wavelength[CL6_150_800_500LP$Wavelength < 960],
        CL6_150_800_500LP$Intensity[CL6_150_800_500LP$Wavelength < 960]/
          max(CL6_150_800_500LP$Intensity),
        col=1)
  
  
  axis(side=1, at=seq(200,1600,200), labels=TRUE)
  axis(side=2, at=c(0,0.5,1))
  
  par(new=TRUE, fig=c(0,0.5,0,1))
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n", 
       ylab="", yaxt="n")
  
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  
  text(x=PlotLim[1]*1.16,y=1,"(a)", cex=1.3)
  
  #300/500
  PlotLim=c(c(500,1200))
  
  par(new=TRUE, fig=c(0.5,1,0.4,1))
  plot(PlotX,          
       approx(x=CL6_Irr$Wavelength,
              y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y/max(
                approx(x=CL6_Irr$Wavelength,
                       y=CL6_Irr$Rel_Photon_Emission, xout=PlotX)$y) ,
       type="l", lty=2, 
       xaxs="i",
       bty="n", xaxt="n",  yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       xlab="", ylab="Signal (a.u.)")
  
  axis(side=1, at=seq(200,1600,200), labels=FALSE)
  axis(side=2, at=c(0,0.5,1))
  
  legend("bottomright", legend=c("Emitted", "Measured"), lty=c(2,1), cex=1.2)
  
  
  par(new=TRUE, fig=c(0.5,1,0,0.55))
  plot(CL6_300_500_500LP$Wavelength, #[CL6_300_500_500LP$Wavelength %between% c(300,960)],
       CL6_300_500_500LP$Intensity/ #[CL6_300_500_500LP$Wavelength %between% c(300,960)]/ 
         max(CL6_300_500_500LP$Intensity),
       type="l", lty=1, 
       xaxs="i",
       bty="n",  xaxt="n", yaxt="n",
       xlim=PlotLim, ylim=c(0,1),
       col="darkgrey",
       xlab="Wavelength (nm)", ylab="Signal (a.u.)")
  
  lines(CL6_300_500_500LP$Wavelength[CL6_300_500_500LP$Wavelength < 960],
        CL6_300_500_500LP$Intensity[CL6_300_500_500LP$Wavelength < 960]/
          max(CL6_300_500_500LP$Intensity),
        col=1)
  axis(side=1, at=seq(200,1600,200), labels=TRUE)
  axis(side=2, at=c(0,0.5,1))
  
  par(new=TRUE, fig=c(0.5,1,0,1))
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n", 
       ylab="", yaxt="n")
  
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  
  text(x=PlotLim[1]*1.06, y=1,"(b)", cex=1.3)
  dev.off()
}




## SRF lamp vs datasheet -------------------------------------------------------

{pdf(paste0("output/", "Fig6_SRF_CalibLamp_ClosedSlit_150-800_+_300-500_2.pdf"), width = 14, height = 6)
  
  par(mar=c(5,5,1,2), mgp=c(3,1,0), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #(a)
  matching_wavelength <- 700
  PlotLim <- c(c(300,1400))
  PlotX <- 200:1400
  
  par(fig=c(0,0.5,0,1))
  plot(PlotX,
       approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
         approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
         approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
         approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y /
         #normalise to matching_wavelength
         ( approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
             approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
             approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
             approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
             approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=matching_wavelength, rule=2:2)$y*
             approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y ),
       type="l", 
       xlim=PlotLim,
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Normalised relative transmission (a.u.)",
       col="navyblue", lwd=2, lty=2
  )
  
  #Define SRF (measured/emitted) only for reliable wavelengths (i.e., within first-order limits of 500LP filter (960 nm))
  SRF_lamp_150_800 <- data.frame("Wavelength"=round(CL6_150_800_500LP$Wavelength, 4),
                                 "Factor"=CL6_150_800_500LP$Intensity/approx(x=CL6_Irr$Wavelength,
                                                                             y=CL6_Irr$Intensity/CL6_Irr$Energy, xout=CL6_150_800_500LP$Wavelength)$y
  )[CL6_150_800_500LP$Wavelength < 960,]
  SRF_lamp_150_800$Factor <- SRF_lamp_150_800$Factor/max(SRF_lamp_150_800, na.rm=TRUE)  ## normalise to 1 to later use with apply_EfficiencyCorrection()
  
  lines(SRF_lamp_150_800$Wavelength,
        SRF_lamp_150_800$Factor/SRF_lamp_150_800$Factor[which.min(abs(SRF_lamp_150_800$Wavelength - matching_wavelength))] #normalise to matching_wavelength
        , lwd=2, col=1)
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=PlotLim[1]+40,y=1,"(a)", cex=1.3)
  
  
  legend(x=1000, y=0.25, legend=  sapply(c(bquote("S"["total datasheet"]), bquote("S"["total CL6 lamp"])),as.expression),
         lty=c(2,1), lwd=c(1.5,1.5), col=c("navyblue",1))
  
  par(new=TRUE)
  par(fig=c(0.22,0.5,0.45,1), mar=c(5,7,1,2), mgp=c(2,1,0))
  PlotX <- SRF_lamp_150_800$Wavelength
  plot(PlotX,
       (approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y /
          #normalise to matching_wavelength
          ( approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
              approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
              approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
              approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
              approx(x=Grating150_800_QE$Wavelength, y=Grating150_800_QE$QE, xout=matching_wavelength, rule=2:2)$y*
              approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y ) ) - 
         (SRF_lamp_150_800$Factor/SRF_lamp_150_800$Factor[which.min(abs(SRF_lamp_150_800$Wavelength - matching_wavelength))]),
       type="l", 
       xaxt="n", yaxt="n",
       ylim=c(-0.25,0.45),
       xlab="", ylab="Relative transmission \n difference (a.u.)", cex.lab=1, cex.axis=1,
       col=1, lwd=2, lty=1
  )
  axis(side=1, at=seq(200,1200,200), cex.axis=1)
  axis(side=1, at=seq(200,1200,100), labels=FALSE, tck=-0.02)
  axis(side=2, at=seq(-0.2,0.4,0.2), cex.axis=1)
  abline(h=0, lty=2, col="darkgrey")
  
  #(b)
  PlotLim <- c(450,1000)
  PlotX <- 200:1200
  
  par(new=TRUE)
  par(fig=c(0.5,1,0,1), mar=c(5,5,1,2), mgp=c(3,1,0))
  plot(PlotX,
       approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
         approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
         approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
         approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
         approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y/
         (      approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
                  approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
                  approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
                  approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
                  approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=matching_wavelength, rule=2:2)$y*
                  approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y)
       ,
       type="l", 
       xlim=PlotLim,
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Normalised relative transmission (a.u.)",
       col="navyblue", lwd=2, lty=2
  )
  
  #Define SRF (measured/emitted) only for reliable wavelengths (i.e., within first-order limits of 500LP filter (960 nm))
  SRF_lamp_300_500 <- data.frame("Wavelength"=round(CL6_300_500_500LP$Wavelength, 4),
                                 "Factor"=CL6_300_500_500LP$Intensity/approx(x=CL6_Irr$Wavelength,
                                                                             y=CL6_Irr$Intensity/CL6_Irr$Energy, xout=CL6_300_500_500LP$Wavelength)$y
  )[CL6_300_500_500LP$Wavelength < 960,]
  SRF_lamp_300_500$Factor <- SRF_lamp_300_500$Factor/max(SRF_lamp_300_500, na.rm=TRUE)  ## normalise to 1 to later use with apply_EfficiencyCorrection()
  
  lines(SRF_lamp_300_500$Wavelength,
        SRF_lamp_300_500$Factor/SRF_lamp_300_500$Factor[which.min(abs(SRF_lamp_300_500$Wavelength - matching_wavelength))] ##normalise to matching_wavelength
        , lwd=2, col=1)
  
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  legend("bottom", legend=  sapply(c(bquote("S"["total datasheet"]), bquote("S"["total CL6 lamp"])),as.expression),
         lty=c(2,1), lwd=c(1.5,1.5), col=c("navyblue",1))
  
  points(PlotX, y=rep(-0.05,length(PlotX)), col= unlist( lapply(PlotX, function(x) nm2rgb(x))), cex=2 )
  
  text(x=PlotLim[1]*1.05,y=1,"(b)", cex=1.3)
  
  
  par(new=TRUE)
  par(fig=c(0.72,1,0.45,1), mar=c(5,7,1,2), mgp=c(2,1,0))
  PlotX <- SRF_lamp_300_500$Wavelength
  plot(PlotX,
       (approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=PlotX, rule=2:2)$y*
          approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=PlotX, rule=2:2)$y*
          approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=PlotX, rule=2:2)$y*
          approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=PlotX, rule=2:2)$y*
          approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=PlotX, rule=2:2)$y/
          (      approx(x=LongPassFilter500_T$Wavelength,  y=LongPassFilter500_T$Transmission, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=AttachmentOptics$Wavelength, y=AttachmentOptics$Transmission, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=Fibre_T$Wavelength, y=Fibre_T$Transmittance, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=SpecCoating_R$Wavelength, y=SpecCoating_R$Reflectivity, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=Grating300_500_QE$Wavelength, y=Grating300_500_QE$QE, xout=matching_wavelength, rule=2:2)$y*
                   approx(x=CCDCameraQE$Wavelength, y=CCDCameraQE$QE, xout=matching_wavelength, rule=2:2)$y) ) - 
         (SRF_lamp_300_500$Factor/SRF_lamp_300_500$Factor[which.min(abs(SRF_lamp_300_500$Wavelength - matching_wavelength))]),
       type="l", 
       xaxt="n", yaxt="n",
       ylim=c(-0.25,0.45),
       xlab="", ylab="Relative transmission \n difference (a.u.)", cex.lab=1, cex.axis=1,
       col=1, lwd=2, lty=1
  )
  axis(side=1, at=seq(200,1200,200), cex.axis=1)
  axis(side=1, at=seq(200,1200,100), labels=FALSE, tck=-0.02)
  axis(side=2, at=seq(-0.2,0.4,0.2), cex.axis=1)
  abline(h=0, lty=2, col="darkgrey")
  dev.off()
}




## Example SRF use in RF -------------------------------------------------------

#get data file locations
xsygNames <- dir(getwd(), pattern = c('xsyg'), recursive = TRUE, ignore.case = TRUE)
xsygNames_BG   <- xsygNames[ grepl(xsygNames,pattern="Empty")]
xsygNames_Data <- xsygNames[!grepl(xsygNames,pattern="Empty")]

#run analysis for all background files
for (b in 1:length(xsygNames_BG)) {
  
  print(c("b=",b," of ",length(xsygNames_BG)))
  

  #load data
  obj_xsyg <- read_XSYG2R(
    xsygNames[b],
    recalculate.TL.curves = TRUE,
    fastForward = FALSE,
    import = TRUE,
    pattern = ".xsyg",
    verbose = TRUE,
    txtProgressBar = TRUE
  )
  
  
  
  #analyse
  
  temp_obj <- obj_xsyg[[1]][["Sequence.Object"]]@records[[1]]
  
  if(grepl(temp_obj@recordType, pattern = "(Spectrometer)" ) ){
    
    #Calibrate wavelength
    if(grepl(xsygNames_BG[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800)
      
    } else if(grepl(xsygNames_BG[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500)
      
    } else { print("Error in re-calibration of wavelength!")}
    
   
   #Define sample name 
    if(grepl(xsygNames_BG[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      s=paste0("Empty_150-800_", b)
      
    } else if(grepl(xsygNames_BG[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      s=paste0("Empty_300-500_", b)
      
    } else { print("No grating specified!")}
    
    #remove outliers 
    plot_RLum.Data.Spectrum(temp_obj, main="0")
    
    temp_obj_noCosmic <- temp_obj
    
    
    for (n in 1:5) {
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 1,   #first smooth along t axis,
                                                  method =  "smooth")
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 2,   #then smooth along wavelength axis
                                                  method =  "smooth")
      
      
      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n)
      
      
    }
    
    
   #Get median background
    medianBG <- unlist(lapply(1:nrow(temp_obj_noCosmic@data), function (x) median(temp_obj_noCosmic@data[x,]) ))
    
    plot(rownames(temp_obj_noCosmic@data),
         medianBG,
         xlab="Wavelength (nm)",
         ylab="Median RF backgroud (cts/1.3 Gy)",
         type="l") 
    

    #save background
    assign(s, medianBG)
    
    
  } else {print("Wrong record type.")} #end if correct record type
}#end for xsyg


#run analysis for all data files
for (b in 1:length(xsygNames_Data)) {
  
  print(c("b=",b," of ",length(xsygNames_Data)))
  
  #load BG
  BG <-  if(grepl(xsygNames_Data[b], pattern = "150-800")) {
    eval(as.symbol("Empty_150-800_1"))
  } else if(grepl(xsygNames_Data[b], pattern = "300-500")) {
    eval(as.symbol("Empty_300-500_2"))
  } else {print("No BG available")}
  
  
  #load data
  obj_xsyg <- read_XSYG2R(
    xsygNames_Data[b],
    recalculate.TL.curves = TRUE,
    fastForward = FALSE,
    import = TRUE,
    pattern = ".xsyg",
    verbose = TRUE,
    txtProgressBar = TRUE
  )
  
  
  #analyse
   temp_obj <- obj_xsyg[[1]][["Sequence.Object"]]@records[[1]]
  
  if(grepl(temp_obj@recordType, pattern = "(Spectrometer)" ) ){
    
    #Background removal 
    temp_obj@data <- temp_obj@data - rep(BG, ncol(temp_obj@data))
    

    #Calibrate wavelength
    if(grepl(xsygNames_Data[b], pattern="150-800") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_150_800)
      
    } else if(grepl(xsygNames_Data[b], pattern="300-500") & nrow(temp_obj)==1024){
      
      rownames( temp_obj@data) <- Pixel2Wavelength(pixel=1:1024, WlCalPars=WlCalPars_lm_300_500)
      
    } else { print("Error in re-calibration of wavelength!")}
    
    s=paste0("Gi326_90-200um_", b)
    
    #remove outliers 
    plot_RLum.Data.Spectrum(temp_obj, main="0")
    
    temp_obj_noCosmic <- temp_obj
    
    
    for (n in 1:5) {
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 1,   #first smooth along t axis,
                                                  method =  "smooth")
      temp_obj_noCosmic <- apply_CosmicRayRemoval(temp_obj_noCosmic,
                                                  MARGIN = 2,   #then smooth along wavelength axis
                                                  method =  "smooth")
      
      
      plot_RLum.Data.Spectrum(temp_obj_noCosmic, main=n)
      
      
    }
    
    #round wavelength to match SRF
    rownames(temp_obj_noCosmic@data) <- round(as.numeric(rownames(temp_obj_noCosmic@data)),4)
    
    #build example of raw data
    temp_data <- data.frame("Wavelength"=rownames(temp_obj_noCosmic@data),
                            "Signal_raw"=temp_obj_noCosmic@data[,9]) 
    
    if(grepl(xsygNames_Data[b], pattern = "LP500") | grepl(xsygNames_Data[b], pattern = "500LP")){
      
      #remove data outside first-order signal wavelength range
      temp_obj_noCosmic@data <- temp_obj_noCosmic@data[as.numeric(rownames(temp_obj_noCosmic@data)) %between% c(525,960),]
      
      
      
      #Efficiency correction S_datasheet
      if(grepl(xsygNames_Data[b], pattern="150-800") ){
        
        temp_obj_noCosmic_Datasheet <- apply_EfficiencyCorrection(temp_obj_noCosmic, SRF_datasheet_150_800)
        
      } else if(grepl(xsygNames_Data[b], pattern="300-500") ){
        
        temp_obj_noCosmic_Datasheet <- apply_EfficiencyCorrection(temp_obj_noCosmic, SRF_datasheet_300_500)
        
      } 
      
      #save S_datasheet-corrected spectrum
      temp_data <- left_join(temp_data,
                             data.frame("Wavelength"=rownames(temp_obj_noCosmic_Datasheet@data),
                                        "Signal_Corr_Datasheet"=temp_obj_noCosmic_Datasheet@data[,9])
      )
      
      
      #Efficiency correction S_lamp
      if(grepl(xsygNames_Data[b], pattern="150-800") ){
        
        temp_obj_noCosmic_Lamp <- apply_EfficiencyCorrection(temp_obj_noCosmic, SRF_lamp_150_800)
        
      } else if(grepl(xsygNames_Data[b], pattern="300-500") ){
        
        temp_obj_noCosmic_Lamp <- apply_EfficiencyCorrection(temp_obj_noCosmic, SRF_lamp_300_500)
        
      }
      
      #save S_lamp-corrected spectrum
      temp_data <- left_join(temp_data,
                             data.frame("Wavelength"=rownames(temp_obj_noCosmic_Lamp@data),
                                        "Signal_Corr_Lamp"=temp_obj_noCosmic_Lamp@data[,9])
      )
      
      #Get details on IR-RF peak position
      print(paste0("The IR-RF peak centre wavelength of the raw data is ", round(mean(as.numeric(rownames(temp_obj_noCosmic@data))[temp_obj_noCosmic@data[,10]==max(temp_obj_noCosmic@data[,10])])), " nm."))
      print(paste0("The IR-RF peak centre wavelength of the SRF_datasheet-corrected spectrum is ", round(mean(as.numeric(rownames(temp_obj_noCosmic_Datasheet@data))[temp_obj_noCosmic_Datasheet@data[,10]==max(temp_obj_noCosmic_Datasheet@data[,10])])), " nm."))
      print(paste0("The IR-RF peak centre wavelength of the SRF_lamp-corrected spectrum is ", round(mean(as.numeric(rownames(temp_obj_noCosmic_Lamp@data))[temp_obj_noCosmic_Lamp@data[,10]==max(temp_obj_noCosmic_Lamp@data[,10])])), " nm."))
      
    } #end if 500LP filter
    
    #save example of raw data
    assign(paste0("Data_", s), temp_data)
    
    
  } else {print("Wrong record type.")} #end if correct record type
}#end for xsyg



##Plot Fig. 7
{ pdf(paste0("output/", "Fig7_SRF_RF.pdf"), width = 7*2, height = 6)
  
  par(mfcol=c(1,2), mar=c(5,5,1,2), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #(a)
  #150-800 grating
  PlotLim <- c(400,1400)
  
  s=paste0("Gi326_90-200um_",  grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800_KF_90-200um_gau")) 
  
  #load data
  temp_data <- eval(as.symbol(paste0("Data_", s)))
  
  #plot raw spectrum
  plot(temp_data$Wavelength,
       temp_data$Signal_raw/max(temp_data$Signal_raw, na.rm=TRUE),
       type="l", lwd=2,
       xlim=PlotLim, ylim=c(0,1),
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Background-corrected RF (a.u.)")  
  
  
  #plot SRF_datasheet-corrected spectrum
  lines(temp_data$Wavelength,
        temp_data$Signal_Corr_Datasheet/max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE),
        col="darkorange")
  
  #plot SRF_lamp-corrected spectrum
  lines(temp_data$Wavelength,
        temp_data$Signal_Corr_Lamp/max(temp_data$Signal_Corr_Lamp, na.rm=TRUE),
        col="steelblue")
  
  
  legend("topleft",  lty=1, title="SRF used",legend= sapply(c("None",
                                                              bquote("S"["total datasheet"]),
                                                              bquote("S"["total CL6 lamp"])),as.expression), 
         col=c(1,"darkorange", "steelblue"), lwd=c(2,1,1), cex=1.2)
  
  #plot peak maxima
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_raw == max(temp_data$Signal_raw, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5)
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_Corr_Datasheet == max(temp_data$Signal_Corr_Datasheet, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_Corr_Lamp == max(temp_data$Signal_Corr_Lamp, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="steelblue")
  
  

  #add wavelength colour bar  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.05,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=2 )
  
  text(x=440,y=1,"(a)", cex=1.3)
  
  #Details (not plotted)
  print(paste0("150/800 grating: ",
               round(100*min((temp_data$Signal_Corr_Lamp[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                max(temp_data$Signal_Corr_Lamp, na.rm=TRUE)) /
                               (temp_data$Signal_Corr_Datasheet[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                  max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE)) )), " to ",
               round(100*max((temp_data$Signal_Corr_Lamp[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                max(temp_data$Signal_Corr_Lamp, na.rm=TRUE)) /
                               (temp_data$Signal_Corr_Datasheet[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                  max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE)) )), "%"))
 
   #(b)
  #300-500 grating
  PlotLim <- c(500,1100)
  
  s=paste0("Gi326_90-200um_",  grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_300-500_KF_90-200um_gau")) 
  
  #load data
  temp_data <- eval(as.symbol(paste0("Data_", s)))
  
  #plot raw spectrum
  plot(temp_data$Wavelength,
       temp_data$Signal_raw/max(temp_data$Signal_raw, na.rm=TRUE),
       type="l", lwd=2,
       xlim=PlotLim, ylim=c(0,1),
       xaxs="i",
       xlab="Wavelength (nm)", ylab="Background-corrected RF (a.u.)")  
  
  
  #plot SRF_datasheet-corrected spectrum
  lines(temp_data$Wavelength,
        temp_data$Signal_Corr_Datasheet/max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE),
        col="darkorange")
  
  #plot SRF_lamp-corrected spectrum
  lines(temp_data$Wavelength,
        temp_data$Signal_Corr_Lamp/max(temp_data$Signal_Corr_Lamp, na.rm=TRUE),
        col="steelblue")
  
  
  legend("topleft",  lty=1, title="SRF used",legend= sapply(c("None",
                                                              bquote("S"["total datasheet"]),
                                                              bquote("S"["total CL6 lamp"])),as.expression), 
         col=c(1,"darkorange", "steelblue"), lwd=c(2,1,1), cex=1.2)
  
  #plot peak maxima
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_raw == max(temp_data$Signal_raw, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5)
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_Corr_Datasheet == max(temp_data$Signal_Corr_Datasheet, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="darkorange")
  points(x=mean(as.numeric(temp_data$Wavelength[which(temp_data$Signal_Corr_Lamp == max(temp_data$Signal_Corr_Lamp, na.rm = TRUE))])),
         y=0.02, pch="|", cex=1.5, col="steelblue")
  
  #add wavelength colour bar  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xaxs="i",
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.05,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=2 )
  
  text(x=520,y=1,"(b)", cex=1.3)
  
  #Details (not plotted)
  print(paste0("300/500 grating: ",
               round(100*min((temp_data$Signal_Corr_Lamp[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                max(temp_data$Signal_Corr_Lamp, na.rm=TRUE)) /
                               (temp_data$Signal_Corr_Datasheet[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                  max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE)) )), " to ",
               round(100*max((temp_data$Signal_Corr_Lamp[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                max(temp_data$Signal_Corr_Lamp, na.rm=TRUE)) /
                               (temp_data$Signal_Corr_Datasheet[round(as.numeric(temp_data$Wavelength)) %between% c(850,950)]/
                                  max(temp_data$Signal_Corr_Datasheet, na.rm=TRUE)) )), "%"))
  
  dev.off()
}# end plot




# Plot Fig B1: Filter comparison -----------------------------------------------
{pdf(paste0("output/", "FigB1_SRF_Raw_FilterComparison.pdf"), width = 7, height = 6)
  
  par(mar=c(5,5,1,1), cex=1.2, cex.lab=1.3, cex.axis=1.2)
  
  #150-800
  PlotLim <- c(350,1450)
  
  
  #load data from 500LP measurement
  s=paste0("Gi326_90-200um_",  grep(xsygNames_Data, pattern = "Gi326_500LP_RF70_SpecF_150-800_KF_90-200um_gau")) 
  
  temp_data <- eval(as.symbol(paste0("Data_", s)))
  
  plot(temp_data$Wavelength,
       temp_data$Signal_raw,
       type="l",
       xlim=PlotLim,
       ylab="Background-corrected RF (cts/1.3 Gy)",  #source dose rate * channel length = 0.068 Gy/s * 19 s
       xlab="Wavelength (nm)") 
  
  
  #load data from 850LP measurement
  s=paste0("Gi326_90-200um_",  grep(xsygNames_Data, pattern = "Gi326_850LP_RF70_SpecF_150-800_KF_90-200_gau")) 
  
  temp_data <- eval(as.symbol(paste0("Data_", s)))
  
  #plot
  lines(temp_data$Wavelength,
        temp_data$Signal_raw, col=2)
  
  legend("topright",  lty=1, title="Filter", legend=c("500LP", "850LP"), col=c(1,2), cex=1.2)
  
  #mark boundaries of first-order signal
  abline(v=480, lty=2, col="darkgrey")
  abline(v=480*2, lty=2, col="darkgrey")
  
  par(new=TRUE)
  plot(NA,NA,
       xlim=PlotLim,
       ylim=c(0,1),
       xlab="", xaxt="n",
       ylab="", yaxt="n")
  
  points(200:1500, y=rep(-0.05,length(200:1500)), col= unlist( lapply(200:1500, function(x) nm2rgb(x))), cex=2 )
  
  dev.off()
}
